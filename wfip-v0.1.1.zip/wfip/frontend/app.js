/* WFIP investigator dashboard */
const API = "/api";
const S = {
  token: localStorage.getItem("wfip_token"),
  user: JSON.parse(localStorage.getItem("wfip_user") || "null"),
  caseId: localStorage.getItem("wfip_case") || "",
  cases: [],
};
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "-").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const badge = (txt, cls) => `<span class="badge ${cls}">${esc(txt)}</span>`;
const statusBadge = (s) => badge(s, s === "OK" || s === "COLLECTED" ? "ok" : (s === "NOT_FOUND" ? "warn" : "err"));
const provBadge = (p) => badge(p, p === "OBSERVED" ? "obs" : (p === "CORRELATED" ? "warn" : "err"));

async function api(path, opts = {}) {
  const res = await fetch(API + path, {
    ...opts,
    headers: { "Content-Type": "application/json",
      ...(S.token ? { Authorization: "Bearer " + S.token } : {}),
      ...(opts.headers || {}) },
  });
  if (res.status === 401) { logout(); throw new Error("session expired"); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || `HTTP ${res.status}`);
  return data;
}
async function apiForm(path, formData) {
  const res = await fetch(API + path, { method: "POST",
    headers: S.token ? { Authorization: "Bearer " + S.token } : {}, body: formData });
  if (res.status === 401) { logout(); throw new Error("session expired"); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || `HTTP ${res.status}`);
  return data;
}

/* ---------- auth ---------- */
function showLogin() { $("login-screen").classList.remove("hidden"); $("app").classList.add("hidden"); }
function showApp() { $("login-screen").classList.add("hidden"); $("app").classList.remove("hidden"); }
function logout() {
  localStorage.removeItem("wfip_token"); localStorage.removeItem("wfip_user");
  S.token = null; S.user = null; showLogin();
}
async function doLogin() {
  $("login-error").classList.add("hidden");
  try {
    const r = await api("/auth/login", { method: "POST", body: JSON.stringify({
      username: $("login-user").value, password: $("login-pass").value,
      totp_code: $("login-totp").value || null }) });
    S.token = r.access_token; S.user = { username: r.username, role: r.role };
    localStorage.setItem("wfip_token", S.token);
    localStorage.setItem("wfip_user", JSON.stringify(S.user));
    if (r.username === "admin") provBanner("Default admin credentials are in use — change the password immediately (profile → not implemented in UI; use API).");
    await boot();
  } catch (e) {
    if (/MFA/i.test(e.message)) $("login-totp-wrap").classList.remove("hidden");
    $("login-error").textContent = e.message; $("login-error").classList.remove("hidden");
  }
}
function provBanner(msg) {
  const b = $("provenance-banner"); b.textContent = msg; b.classList.remove("hidden");
  setTimeout(() => b.classList.add("hidden"), 12000);
}

/* ---------- boot / nav ---------- */
async function boot() {
  showApp();
  $("user-badge").textContent = `${S.user.username} · ${S.user.role}`;
  await loadCases();
  nav("dashboard");
}
async function loadCases() {
  S.cases = await api("/cases");
  const sel = $("case-select");
  sel.innerHTML = `<option value="">— select —</option>` + S.cases.map(c =>
    `<option value="${c.id}" ${c.id === S.caseId ? "selected" : ""}>${esc(c.case_id)} · ${esc(c.title)}</option>`).join("");
}
function activeCase() { return S.cases.find((c) => c.id === S.caseId); }
function needCase() {
  if (!S.caseId) { $("view").innerHTML = `<div class="card"><h3>No active case</h3><p class="muted">Select or create a case to begin investigating.</p></div>`; return false; }
  return true;
}
function nav(view) {
  document.querySelectorAll("#nav button").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  ({ dashboard: vDashboard, cases: vCases, collect: vCollect, entities: vEntities,
     evidence: vEvidence, graph: vGraph, timeline: vTimeline, reports: vReports,
     assistant: vAssistant, sources: vSources, audit: vAudit })[view]();
}
document.querySelectorAll("#nav button").forEach((b) => b.onclick = () => nav(b.dataset.view));
$("login-btn").onclick = doLogin;
$("logout-btn").onclick = logout;
$("theme-btn").onclick = () => {
  const h = document.documentElement;
  h.dataset.theme = h.dataset.theme === "dark" ? "light" : "dark";
};
$("case-select").onchange = (e) => { S.caseId = e.target.value; localStorage.setItem("wfip_case", S.caseId); nav("dashboard"); };
$("new-case-btn").onclick = () => $("case-modal").classList.remove("hidden");
$("nc-cancel").onclick = () => $("case-modal").classList.add("hidden");
$("nc-create").onclick = async () => {
  const c = await api("/cases", { method: "POST", body: JSON.stringify({
    title: $("nc-title").value, description: $("nc-desc").value, classification: $("nc-class").value }) });
  $("case-modal").classList.add("hidden"); S.caseId = c.id;
  localStorage.setItem("wfip_case", S.caseId); await loadCases(); nav("dashboard");
};
$("search-btn").onclick = async () => {
  const q = $("global-search").value.trim(); if (q.length < 2) return;
  const r = await api(`/search?q=${encodeURIComponent(q)}`);
  $("view").innerHTML = `<div class="card"><h3>Search: ${esc(q)}</h3>
    <h4>Entities (${r.entities.length})</h4>
    <table><tr><th>Type</th><th>Value</th><th>Entity ID</th></tr>
    ${r.entities.map((e) => `<tr><td>${esc(e.type)}</td><td class="mono">${esc(e.value)}</td><td class="mono">${esc(e.entity_id)}</td></tr>`).join("")}</table>
    <h4>Evidence (${r.evidence.length})</h4>
    <table><tr><th>Evidence ID</th><th>Target</th><th>SHA-256</th></tr>
    ${r.evidence.map((e) => `<tr><td><a href="#" data-ev="${e.evidence_id}">${esc(e.evidence_id)}</a></td><td class="mono">${esc(e.target)}</td><td class="mono">${esc(e.sha256.slice(0, 24))}…</td></tr>`).join("")}</table></div>`;
  bindEvLinks();
};
function bindEvLinks() {
  document.querySelectorAll("[data-ev]").forEach((a) => a.onclick = (e) => { e.preventDefault(); openEvidence(a.dataset.ev); });
}

/* ---------- dashboard ---------- */
async function vDashboard() {
  if (!needCase()) return;
  const c = await api(`/cases/${S.caseId}`);
  const [ev, tl] = await Promise.all([
    api(`/cases/${S.caseId}/evidence`), api(`/cases/${S.caseId}/timeline`)]);
  const failed = ev.filter((e) => e.collection_status !== "OK");
  $("view").innerHTML = `
    <div class="card"><div class="row between"><div>
      <h3 style="margin:0">${esc(c.case_id)} — ${esc(c.title)}</h3>
      <p class="muted small">${esc(c.classification)} · ${esc(c.status)} · created ${esc(c.created_at.slice(0, 10))}</p>
      <p>${esc(c.description || "No description.")}</p></div>
      <div>${statusBadge(c.status)}</div></div></div>
    <div class="card"><h3>🔍 Quick internet lookup</h3>
      <p class="muted small">Yahan target likho — WFIP <strong>abhi internet se real data</strong> nikal kar layega
      (DNS records, RDAP registration, certificates, website forensics, IP intel) aur sab kuch evidence ki
      soorat mein save karega. Koi fake/demo data nahi.</p>
      <div class="row">
        <select id="q-kind" style="width:auto">
          <option value="domain">Domain (DNS + RDAP + certs)</option>
          <option value="ip">IP address</option>
          <option value="url">Website / URL</option>
          <option value="rdap">RDAP lookup</option>
          <option value="tls">TLS certificate</option>
        </select>
        <input id="q-target" placeholder="e.g. example.com" style="width:280px;margin:0">
        <button id="q-go" class="btn primary">Find data</button>
      </div>
      <div id="q-out" style="margin-top:.8rem"></div>
    </div>
    <div class="grid">
      <div class="stat"><div class="n">${ev.length}</div><div class="l">Evidence items</div></div>
      <div class="stat"><div class="n">${c.entity_count}</div><div class="l">Entities</div></div>
      <div class="stat"><div class="n">${tl.length}</div><div class="l">Timeline events</div></div>
      <div class="stat"><div class="n">${failed.length}</div><div class="l">Failed collections</div></div>
    </div>
    <div class="card"><h3>Recent evidence</h3>
      <table><tr><th>Evidence ID</th><th>Type</th><th>Target</th><th>Status</th><th>Collected</th></tr>
      ${ev.slice(0, 8).map((e) => `<tr><td><a href="#" data-ev="${e.evidence_id}">${esc(e.evidence_id)}</a></td>
        <td>${esc(e.evidence_type)}</td><td class="mono">${esc(e.target.slice(0, 60))}</td>
        <td>${statusBadge(e.collection_status)}</td><td class="small">${esc(e.collected_at.slice(0, 16).replace("T", " "))}</td></tr>`).join("")}
      </table></div>`;
  bindEvLinks();
  const qgo = $("q-go");
  if (qgo) qgo.onclick = async () => {
    const kind = $("q-kind").value, target = $("q-target").value.trim();
    if (!target) { $("q-out").innerHTML = `<p class="error">Pehle target likho.</p>`; return; }
    $("q-out").innerHTML = `<p class="muted">Internet se data collect ho raha hai… (DNS, RDAP, certificates)</p>`;
    qgo.disabled = true;
    try {
      const r = await api(`/collect/${kind}`, { method: "POST",
        body: JSON.stringify({ case_id: S.caseId, target }) });
      $("q-out").innerHTML = r.collections.map((c) =>
        `<p>${statusBadge(c.status)} <span class="mono">${esc(c.evidence_id)}</span>
         <span class="muted small">${esc((c.errors || []).join("; ") || c.collector || "")}</span></p>`).join("") +
        `<p><button class="btn primary" id="q-view">📊 Natija dekho (Evidence + Graph)</button></p>
         <p class="muted small">Har collection ka raw data, hash aur source Evidence tab mein mehfooz hai.</p>`;
      $("q-view").onclick = () => nav("evidence");
    } catch (e) { $("q-out").innerHTML = `<p class="error">${esc(e.message)}</p>`; }
    qgo.disabled = false;
  };
}

/* ---------- cases ---------- */
async function vCases() {
  const cases = await api("/cases");
  $("view").innerHTML = `<div class="card"><h3>Cases (${cases.length})</h3>
    <table><tr><th>Case ID</th><th>Title</th><th>Classification</th><th>Status</th><th>Created</th><th></th></tr>
    ${cases.map((c) => `<tr><td class="mono">${esc(c.case_id)}</td><td>${esc(c.title)}</td>
      <td>${esc(c.classification)}</td><td>${statusBadge(c.status)}</td>
      <td class="small">${esc(c.created_at.slice(0, 10))}</td>
      <td><button class="btn" data-open="${c.id}">Open</button></td></tr>`).join("")}</table></div>`;
  document.querySelectorAll("[data-open]").forEach((b) => b.onclick = () => {
    S.caseId = b.dataset.open; localStorage.setItem("wfip_case", S.caseId);
    $("case-select").value = S.caseId; nav("dashboard");
  });
}

/* ---------- investigations (collect) ---------- */
async function vCollect() {
  if (!needCase()) return;
  $("view").innerHTML = `<div class="card"><h3>New collection</h3>
    <p class="muted small">Every collection is stored as immutable evidence with source, timestamp, method, hash and audit trail. Failed or unavailable sources are reported honestly — never mocked.</p>
    <div class="row">
      <select id="col-kind" style="width:auto">
        <option value="domain">Domain (DNS + RDAP + certs + TLS)</option>
        <option value="ip">IP address</option>
        <option value="url">URL / website</option>
        <option value="rdap">RDAP lookup</option>
        <option value="tls">TLS certificate</option>
      </select>
      <input id="col-target" placeholder="target, e.g. example.com" style="width:300px;margin:0">
      <button id="col-run" class="btn primary">Collect</button>
    </div>
    <div class="row" style="margin-top:.8rem">
      <input id="col-file" type="file" style="width:auto">
      <button id="col-email" class="btn">Upload .eml</button>
      <button id="col-filebtn" class="btn">Upload file evidence</button>
    </div>
    <div id="col-out" style="margin-top:1rem"></div></div>
    <div class="card"><h3>Collection jobs</h3><div id="jobs"></div></div>`;
  $("col-run").onclick = async () => {
    const kind = $("col-kind").value, target = $("col-target").value.trim();
    if (!target) return;
    $("col-out").innerHTML = `<p class="muted">Collecting…</p>`;
    try {
      const r = await api(`/collect/${kind}`, { method: "POST",
        body: JSON.stringify({ case_id: S.caseId, target }) });
      $("col-out").innerHTML = r.collections.map((c) =>
        `<p>${statusBadge(c.status)} <span class="mono">${esc(c.evidence_id)}</span>
         <span class="muted small">${esc((c.errors || []).join("; "))}</span></p>`).join("");
    } catch (e) { $("col-out").innerHTML = `<p class="error">${esc(e.message)}</p>`; }
  };
  const up = async (kind, file) => {
    if (!file) return;
    const fd = new FormData(); fd.append("file", file);
    $("col-out").innerHTML = `<p class="muted">Uploading & parsing…</p>`;
    try {
      const r = await apiForm(`/collect/${kind}?case_id=${S.caseId}`, fd);
      $("col-out").innerHTML = `<p>${statusBadge(r.status)} <span class="mono">${esc(r.evidence_id)}</span></p>`;
    } catch (e) { $("col-out").innerHTML = `<p class="error">${esc(e.message)}</p>`; }
  };
  $("col-email").onclick = () => up("email", $("col-file").files[0]);
  $("col-filebtn").onclick = () => up("file", $("col-file").files[0]);
}

/* ---------- entities ---------- */
async function vEntities() {
  if (!needCase()) return;
  const types = ["", "domain", "ip", "asn", "url", "email", "certificate", "organization", "nameserver", "mailserver", "file", "hash"];
  $("view").innerHTML = `<div class="card"><div class="row between"><h3>Entities</h3>
    <select id="ent-type" style="width:auto">${types.map((t) => `<option value="${t}">${t || "all types"}</option>`).join("")}</select></div>
    <div id="ent-list"></div></div>`;
  const load = async () => {
    const t = $("ent-type").value;
    const list = await api(`/cases/${S.caseId}/entities${t ? "?type=" + t : ""}`);
    $("ent-list").innerHTML = `<table><tr><th>Type</th><th>Value</th><th>Entity ID</th><th>Last seen</th></tr>
      ${list.map((e) => `<tr><td>${esc(e.type)}</td><td class="mono">${esc(e.value.slice(0, 90))}</td>
        <td><a href="#" data-ent="${e.entity_id}" class="mono">${esc(e.entity_id)}</a></td>
        <td class="small">${esc(e.last_seen.slice(0, 16).replace("T", " "))}</td></tr>`).join("")}</table>`;
    document.querySelectorAll("[data-ent]").forEach((a) => a.onclick = async (ev2) => {
      ev2.preventDefault();
      const d = await api(`/entities/${a.dataset.ent}`);
      $("ent-list").innerHTML = `<button class="btn" id="ent-back">← Back</button>
        <h3 class="mono">${esc(d.value)}</h3><p class="muted">${esc(d.type)} · ${esc(d.entity_id)}</p>
        <pre>${esc(JSON.stringify(d.attributes, null, 2))}</pre>
        <h4>Relationships (${d.relationships.length})</h4>
        <table><tr><th>Dir</th><th>Relationship</th><th>Entity</th><th>Provenance</th><th>Evidence</th><th>Detail</th></tr>
        ${d.relationships.map((r) => `<tr><td>${esc(r.direction)}</td><td>${esc(r.rel_type)}</td>
          <td class="mono">${esc(r.entity.type)}:${esc(r.entity.value.slice(0, 50))}</td>
          <td>${provBadge(r.provenance)}</td>
          <td>${r.evidence_id ? `<a href="#" data-ev="${r.evidence_id}" class="mono">${esc(r.evidence_id)}</a>` : "-"}</td>
          <td class="small">${esc(r.detail)}</td></tr>`).join("")}</table>`;
      $("ent-back").onclick = load; bindEvLinks();
    });
  };
  $("ent-type").onchange = load; await load();
}

/* ---------- evidence ---------- */
async function vEvidence() {
  if (!needCase()) return;
  const list = await api(`/cases/${S.caseId}/evidence`);
  $("view").innerHTML = `<div class="card"><h3>Evidence vault (${list.length})</h3>
    <p class="muted small">Append-only. Originals are never overwritten; every access is logged in the chain of custody.</p>
    <table><tr><th>Evidence ID</th><th>Type</th><th>Target</th><th>Source</th><th>Status</th><th>SHA-256</th><th>Collected</th></tr>
    ${list.map((e) => `<tr><td><a href="#" data-ev="${e.evidence_id}" class="mono">${esc(e.evidence_id)}</a></td>
      <td>${esc(e.evidence_type)}</td><td class="mono">${esc(e.target.slice(0, 50))}</td>
      <td>${esc(e.source)}</td><td>${statusBadge(e.collection_status)}</td>
      <td class="mono">${esc(e.sha256.slice(0, 16))}…</td>
      <td class="small">${esc(e.collected_at.slice(0, 16).replace("T", " "))}</td></tr>`).join("")}</table></div>`;
  bindEvLinks();
}
async function openEvidence(eid) {
  const e = await api(`/evidence/${eid}`);
  $("ev-title").textContent = e.evidence_id;
  $("ev-body").innerHTML = `
    <div class="row">${statusBadge(e.collection_status)} ${badge(e.status, e.status === "COLLECTED" ? "ok" : "warn")}</div>
    <table style="margin-top:.8rem">
      <tr><th>Target</th><td class="mono">${esc(e.target)}</td></tr>
      <tr><th>Source</th><td>${esc(e.source)}</td></tr>
      <tr><th>Collector</th><td class="mono">${esc(e.collector)} ${esc(e.collector_version)}</td></tr>
      <tr><th>Collected</th><td>${esc(e.collected_at)}</td></tr>
      <tr><th>SHA-256</th><td class="mono">${esc(e.sha256)}</td></tr>
      ${e.errors.length ? `<tr><th>Notes</th><td>${esc(e.errors.join("; "))}</td></tr>` : ""}
    </table>
    <div class="row" style="margin:.8rem 0">
      <button class="btn" id="ev-verify">Verify hash</button>
      <a class="btn" href="${API}/evidence/${e.evidence_id}/raw" download>Download raw</a>
      <span id="ev-verdict" class="small muted"></span>
    </div>
    <h4>Normalized</h4><pre>${esc(JSON.stringify(e.normalized, null, 2).slice(0, 12000))}</pre>
    <h4>Chain of custody (${e.custody.length})</h4>
    <table><tr><th>Time</th><th>Actor</th><th>Action</th><th>Reason</th><th>Hash</th></tr>
    ${e.custody.map((c) => `<tr><td class="small">${esc(c.timestamp.slice(0, 19).replace("T", " "))}</td>
      <td>${esc(c.actor)}</td><td>${esc(c.action)}</td><td class="small">${esc(c.reason)}</td>
      <td class="mono">${esc((c.hash_at_time || "").slice(0, 12))}…</td></tr>`).join("")}</table>`;
  $("ev-modal").classList.remove("hidden");
  $("ev-verify").onclick = async () => {
    const r = await api(`/evidence/${eid}/verify`, { method: "POST" });
    $("ev-verdict").textContent = r.verified ? "✓ hash verified" : "✗ " + r.message;
  };
}
$("ev-close").onclick = () => $("ev-modal").classList.add("hidden");

/* ---------- graph ---------- */
const TYPE_COLORS = { domain: "#58a6ff", ip: "#3fb950", asn: "#d29922", url: "#a371f7",
  email: "#f778ba", certificate: "#39c5cf", organization: "#e3b341", nameserver: "#8b949e",
  mailserver: "#8b949e", file: "#f85149", hash: "#6e7681" };
async function vGraph() {
  if (!needCase()) return;
  $("view").innerHTML = `<div class="card"><div class="row between"><h3>Entity graph</h3>
    <span class="muted small">Click a node for evidence. Edge color: blue = observed, amber = correlated.</span></div>
    <div style="position:relative"><svg id="graph-svg"></svg><div id="graph-tip" class="hidden"></div></div>
    <div id="graph-legend" class="row small muted" style="margin-top:.5rem"></div></div>`;
  const g = await api(`/cases/${S.caseId}/graph`);
  $("graph-legend").innerHTML = Object.entries(TYPE_COLORS).map(([t, c]) =>
    `<span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${c}"></span> ${t}</span>`).join("");
  drawGraph(g);
}
function drawGraph(g) {
  const svg = $("graph-svg"), tip = $("graph-tip");
  const W = svg.clientWidth || 900, H = 560;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  const nodes = g.nodes.map((n, i) => ({ ...n, x: W / 2 + 200 * Math.cos(i * 2.4), y: H / 2 + 200 * Math.sin(i * 2.4), vx: 0, vy: 0 }));
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
  const edges = g.edges.filter((e) => byId[e.from] && byId[e.to]);
  const NS = "http://www.w3.org/2000/svg";
  const el = (t, a) => { const e = document.createElementNS(NS, t); for (const k in a) e.setAttribute(k, a[k]); return e; };
  edges.forEach((e) => {
    const line = el("line", { stroke: e.provenance === "OBSERVED" ? "#58a6ff" : "#d29922",
      "stroke-width": 1.2, opacity: .7 });
    line.dataset.tip = `${esc(e.label)} · ${esc(e.provenance)}\n${esc(e.detail || "")}\nEvidence: ${esc(e.evidence_id || "-")}`;
    line.onmousemove = (ev2) => showTip(ev2, line.dataset.tip);
    line.onmouseleave = hideTip;
    svg.appendChild(line); e.el = line;
  });
  nodes.forEach((n) => {
    const grp = el("g", { class: "node" });
    grp.appendChild(el("circle", { r: 9, fill: TYPE_COLORS[n.type] || "#8b949e", stroke: "#0d1117", "stroke-width": 2 }));
    const t = el("text", { x: 13, y: 4 }); t.textContent = n.value.length > 34 ? n.value.slice(0, 34) + "…" : n.value;
    grp.appendChild(t);
    grp.onmousemove = (ev2) => showTip(ev2, `${n.type}: ${n.value}\n${n.id}`);
    grp.onmouseleave = hideTip;
    grp.onclick = () => showTip({ clientX: 0, clientY: 0 }, `${n.type}: ${n.value}`);
    svg.appendChild(grp); n.el = grp;
  });
  function showTip(ev2, txt) {
    tip.textContent = txt; tip.classList.remove("hidden");
    tip.style.left = (ev2.clientX + 14) + "px"; tip.style.top = (ev2.clientY + 10) + "px";
  }
  function hideTip() { tip.classList.add("hidden"); }
  // simple force layout
  let iter = 0;
  const tick = () => {
    if (iter++ > 260) return;
    for (let i = 0; i < nodes.length; i++) for (let j = i + 1; j < nodes.length; j++) {
      const a = nodes[i], b = nodes[j];
      let dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy || 1;
      const f = Math.min(9000 / d2, 4);
      dx *= f / Math.sqrt(d2); dy *= f / Math.sqrt(d2);
      a.vx += dx; a.vy += dy; b.vx -= dx; b.vy -= dy;
    }
    edges.forEach((e) => {
      const a = byId[e.from], b = byId[e.to];
      const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 1;
      const f = (d - 130) * 0.02;
      a.vx += dx / d * f * d * 0.05; a.vy += dy / d * f * d * 0.05;
      b.vx -= dx / d * f * d * 0.05; b.vy -= dy / d * f * d * 0.05;
    });
    nodes.forEach((n) => {
      n.vx *= 0.85; n.vy *= 0.85; n.x += n.vx; n.y += n.vy;
      n.x = Math.max(40, Math.min(W - 40, n.x)); n.y = Math.max(30, Math.min(H - 20, n.y));
      n.el.setAttribute("transform", `translate(${n.x},${n.y})`);
    });
    edges.forEach((e) => {
      const a = byId[e.from], b = byId[e.to];
      e.el.setAttribute("x1", a.x); e.el.setAttribute("y1", a.y);
      e.el.setAttribute("x2", b.x); e.el.setAttribute("y2", b.y);
    });
    requestAnimationFrame(tick);
  };
  tick();
}

/* ---------- timeline ---------- */
async function vTimeline() {
  if (!needCase()) return;
  const tl = await api(`/cases/${S.caseId}/timeline`);
  const cls = (c) => c === "CURRENT" ? "ok" : (c === "HISTORICAL" ? "obs" : (c === "INFERENCE" ? "err" : "warn"));
  $("view").innerHTML = `<div class="card"><h3>Timeline (${tl.length})</h3>
    <p class="muted small">CURRENT = observed now · HISTORICAL = source-reported past event · CORRELATION = linked finding · INFERENCE = analyst-grade hypothesis</p>
    <div class="tl">${tl.map((t) => `<div class="tl-item">
      <div class="ts">${esc(t.timestamp.slice(0, 19).replace("T", " "))} ${badge(t.classification, cls(t.classification))}</div>
      <div><strong>${esc(t.event_type)}</strong> <span class="mono">${esc((t.target || "").slice(0, 70))}</span></div>
      <div class="small muted">${esc(t.source || "")} ${t.evidence_id ? `· <a href="#" data-ev="${t.evidence_id}" class="mono">${esc(t.evidence_id)}</a>` : ""}</div>
      <div class="small">${esc(t.detail || "")}</div></div>`).join("") || "<p>No events.</p>"}</div></div>`;
  bindEvLinks();
}

/* ---------- reports ---------- */
async function vReports() {
  if (!needCase()) return;
  $("view").innerHTML = `<div class="card"><div class="row between"><h3>Reports</h3>
    <button id="rep-gen" class="btn primary">Generate report</button></div>
    <div id="rep-list"></div></div>`;
  const load = async () => {
    const reps = await api(`/reports?case_id=${S.caseId}`);
    $("rep-list").innerHTML = `<table><tr><th>Report ID</th><th>Evidence</th><th>SHA-256</th><th>Created</th><th></th></tr>
      ${reps.map((r) => `<tr><td class="mono">${esc(r.report_id)}</td><td>${r.evidence_count}</td>
        <td class="mono">${esc(r.sha256.slice(0, 20))}…</td><td class="small">${esc(r.created_at.slice(0, 16).replace("T", " "))}</td>
        <td><a class="btn" href="${API}/reports/${r.report_id}" target="_blank">Open</a></td></tr>`).join("")}</table>`;
  };
  $("rep-gen").onclick = async () => {
    $("rep-gen").disabled = true; $("rep-gen").textContent = "Generating…";
    try {
      const r = await api(`/reports?case_id=${S.caseId}`, { method: "POST" });
      window.open(`${API}/reports/${r.report_id}`, "_blank");
    } catch (e) { alert("Report failed: " + e.message); }
    $("rep-gen").disabled = false; $("rep-gen").textContent = "Generate report";
    await load();
  };
  await load();
}

/* ---------- assistant ---------- */
async function vAssistant() {
  if (!needCase()) return;
  $("view").innerHTML = `<div class="card"><h3>Investigation assistant</h3>
    <p class="muted small">Grounded strictly in this case's evidence. It will say <em>"Insufficient evidence to establish this finding"</em> when the evidence doesn't support an answer.</p>
    <div class="chat" id="chat"></div>
    <div class="row" style="margin-top:.8rem"><input id="q" placeholder="Summarize the case / list entities / relationships of example.com / show timeline…" style="margin:0">
    <button id="ask" class="btn primary">Ask</button></div></div>`;
  const chat = $("chat");
  const push = (cls, htmlContent) => { const d = document.createElement("div"); d.className = "msg " + cls; d.innerHTML = htmlContent; chat.appendChild(d); chat.scrollTop = chat.scrollHeight; };
  $("ask").onclick = async () => {
    const q = $("q").value.trim(); if (!q) return;
    push("q", esc(q)); $("q").value = "";
    push("a", `<span class="muted">Analyzing evidence…</span>`);
    try {
      const r = await api("/assistant/ask", { method: "POST",
        body: JSON.stringify({ case_id: S.caseId, question: q }) });
      chat.lastChild.remove();
      let htmlContent = `<p>${esc(r.answer)}</p>`;
      if (r.findings) htmlContent += "<ul>" + r.findings.map((f) =>
        `<li>${provBadge(f.classification)} ${esc(f.statement)} <span class="mono">${esc(f.evidence_id)}</span></li>`).join("") + "</ul>";
      if (r.matches) htmlContent += "<ul>" + r.matches.map((m) =>
        `<li>${esc(m.entity)} —<strong>${esc(m.relationship)}</strong>→ ${esc(m.other)} ${provBadge(m.provenance)} <span class="mono">${esc(m.evidence_id || "")}</span><br><span class="muted small">${esc(m.detail || "")}</span></li>`).join("") + "</ul>";
      if (r.issues) htmlContent += "<ul>" + r.issues.map((i) =>
        `<li>${provBadge(i.classification)} ${esc(i.statement)} <span class="mono">${esc(i.evidence_id || "")}</span></li>`).join("") + "</ul>";
      if (r.events) htmlContent += "<ul>" + r.events.map((e) =>
        `<li>${esc(e.timestamp.slice(0, 19).replace("T", " "))} — ${esc(e.event)} ${badge(e.classification, "obs")}</li>`).join("") + "</ul>";
      if (r.entities) htmlContent += "<p>" + Object.entries(r.entities).map(([k, v]) => `${esc(k)}: ${v.length}`).join(" · ") + "</p>";
      if (r.citations && r.citations.length) htmlContent += `<div class="cites">Cited evidence: ${r.citations.map((c) => `<span class="mono">${esc(c)}</span>`).join(", ")}</div>`;
      if (r.grounding) htmlContent += `<div class="cites">${esc(r.grounding)}</div>`;
      push("a", htmlContent);
    } catch (e) { chat.lastChild.remove(); push("a", `<span class="error">${esc(e.message)}</span>`); }
  };
}

/* ---------- sources ---------- */
async function vSources() {
  const s = await api("/system/sources");
  $("view").innerHTML = `<div class="card"><h3>Connector sources</h3>
    <p class="muted small">${esc(s.policy)}</p>
    <table><tr><th>Source</th><th>Collector</th><th>Status</th><th>Setup</th></tr>
    ${s.connectors.map((c) => `<tr><td>${esc(c.name)}</td><td class="mono">${esc(c.collector || "")}</td>
      <td>${badge(c.status, c.status === "READY" || c.status === "CONFIGURED" ? "ok" : "warn")}</td>
      <td class="small muted">${esc(c.setup || c.credentials || "")}</td></tr>`).join("")}</table></div>`;
}

/* ---------- audit ---------- */
async function vAudit() {
  try {
    const rows = await api("/system/audit?limit=200");
    $("view").innerHTML = `<div class="card"><h3>System audit log</h3>
      <table><tr><th>Time</th><th>Actor</th><th>Action</th><th>Target</th><th>Detail</th><th>IP</th></tr>
      ${rows.map((r) => `<tr><td class="small">${esc(r.timestamp.slice(0, 19).replace("T", " "))}</td>
        <td>${esc(r.actor)}</td><td>${esc(r.action)}</td>
        <td class="small">${esc(r.target_type)} ${esc(r.target_id).slice(0, 30)}</td>
        <td class="small">${esc((r.detail || "").slice(0, 120))}</td><td class="small">${esc(r.ip)}</td></tr>`).join("")}</table></div>`;
  } catch (e) {
    $("view").innerHTML = `<div class="card"><p class="error">${esc(e.message)} (admin role required)</p></div>`;
  }
}

/* ---------- init ---------- */
if (S.token && S.user) boot(); else showLogin();
