"""WFIP - World Forensic Intelligence Platform."""
__version__ = "0.1.1"
