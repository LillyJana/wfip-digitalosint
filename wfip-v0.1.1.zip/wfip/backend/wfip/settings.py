"""Central configuration. All secrets come from the environment."""

import os

APP_NAME = "World Forensic Intelligence Platform"
APP_VERSION = "0.1.1"
COLLECTOR_VERSION = "wfip-collectors/0.1.1"

DATABASE_URL = os.environ.get("WFIP_DATABASE_URL", "sqlite:///./wfip.db")
VAULT_DIR = os.environ.get("WFIP_VAULT_DIR", "./vault")
JWT_SECRET = os.environ.get("WFIP_JWT_SECRET", "")
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_SECONDS = int(os.environ.get("WFIP_JWT_EXPIRY", "28800"))  # 8h

# Development fixtures are ONLY usable when this is "1", and anything
# collected with fixtures is permanently labeled DEV_FIXTURE and is
# excluded from production evidence, reports and exports.
DEV_MODE = os.environ.get("WFIP_DEV_MODE", "0") == "1"

RATE_LIMIT_PER_MINUTE = int(os.environ.get("WFIP_RATE_LIMIT", "120"))

# Optional third-party intelligence keys (never required; absence is
# reported honestly as AUTHENTICATION_REQUIRED, never mocked).
VIRUSTOTAL_API_KEY = os.environ.get("VIRUSTOTAL_API_KEY", "")
ABUSEIPDB_API_KEY = os.environ.get("ABUSEIPDB_API_KEY", "")
SHODAN_API_KEY = os.environ.get("SHODAN_API_KEY", "")
URLSCAN_API_KEY = os.environ.get("URLSCAN_API_KEY", "")
HIBP_API_KEY = os.environ.get("HIBP_API_KEY", "")

MAX_HTTP_BODY = int(os.environ.get("WFIP_MAX_HTTP_BODY", str(5 * 1024 * 1024)))
HTTP_TIMEOUT = int(os.environ.get("WFIP_HTTP_TIMEOUT", "25"))

if not JWT_SECRET:
    # Fail closed: the operator must configure a real secret in production.
    # For first-run convenience we allow an ephemeral secret but the audit
    # log records that the deployment is not production-hardened.
    import secrets as _secrets
    JWT_SECRET = _secrets.token_hex(32)
    EPHEMERAL_JWT = True
else:
    EPHEMERAL_JWT = False
