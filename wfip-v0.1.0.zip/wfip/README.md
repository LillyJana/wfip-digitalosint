# WFIP — World Forensic Intelligence Platform

An evidence-driven OSINT and digital-forensics investigation platform for
authorized government, law-enforcement, cybersecurity, incident-response and
forensic investigators.

**Core principle:** every factual finding is traceable to a source, a
collection timestamp, a collection method, raw evidence, a SHA-256 hash, a
normalized representation, an evidence ID and an audit trail. The platform
**never fabricates data** — unavailable sources are reported honestly as
`NOT_FOUND`, `SOURCE_UNAVAILABLE`, `ACCESS_RESTRICTED`,
`AUTHENTICATION_REQUIRED` or `COLLECTION_FAILED`.

## Architecture

```
┌─────────────┐      ┌──────────────┐      ┌─────────────┐
│  Dashboard  │─────▶│   FastAPI    │─────▶│  SQLite /   │
│  (static    │ HTTP │   backend    │      │  PostgreSQL │
│   SPA)      │◀─────│              │◀─────│             │
└─────────────┘      └──────┬───────┘      └─────────────┘
                            │ vault/
                     raw.bin + normalized.json
                     meta.json + SHA-256 + custody log
```

- **Backend:** Python FastAPI (`backend/wfip/`)
- **Frontend:** dependency-free investigator dashboard SPA (`frontend/`)
- **Database:** SQLite by default; PostgreSQL via `WFIP_DATABASE_URL`
- **Evidence vault:** append-only on-disk store (`vault/data/<EV-ID>/`)
- **Connectors:** `backend/wfip/connectors/` — rdap, dns, http, tls,
  certificates (CT), email, ip, file, threat_intel
- **Tests:** `tests/` — forensic validation lab (pytest)

## Quick start (development)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r backend/requirements.txt
cd backend
python -m uvicorn wfip.main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000 — the dashboard is served by the API itself.
Default login: `admin` / `ChangeMe123!` (**change immediately**).

PostgreSQL instead of SQLite:

```bash
export WFIP_DATABASE_URL="postgresql+psycopg2://wfip:secret@db:5432/wfip"
# and uncomment psycopg2-binary in backend/requirements.txt
```

## Production deployment

```bash
cd docker
cp .env.example .env   # fill in real secrets
docker compose up --build -d
```

Optional Kubernetes manifests: `docker/k8s.yaml`.

### Production hardening checklist

- [ ] Set a long random `WFIP_JWT_SECRET` (never use the ephemeral fallback)
- [ ] Change the default admin password; create per-investigator accounts
- [ ] Enable MFA for all accounts (`POST /api/auth/mfa/setup`)
- [ ] Terminate TLS at a reverse proxy (nginx/ingress) — the app serves plain HTTP
- [ ] Use encrypted volumes for PostgreSQL data and the evidence vault
- [ ] Back up the database **and** the vault directory together (they reference each other)
- [ ] Set `WFIP_DEV_MODE=0` (it already defaults to 0)
- [ ] Review `RATE_LIMIT_PER_MINUTE` and put the service behind a WAF for internet exposure
- [ ] Define retention policies per case classification

## How an investigation flows

1. **Create a case** (Cases → + New case), assign investigators.
2. **Collect** (Investigations): run `domain`, `ip`, `url`, `rdap`, `tls`
   collectors, or upload `.eml` / file evidence. Each run becomes one or
   more immutable evidence items.
3. **Inspect**: Evidence vault (raw download, hash verification, chain of
   custody), Entities (with per-relationship provenance), Graph
   (blue = observed, amber = correlated), Timeline
   (CURRENT / HISTORICAL / CORRELATION / INFERENCE).
4. **Ask the assistant** grounded questions — it cites evidence IDs and says
   *"Insufficient evidence to establish this finding"* when appropriate.
5. **Generate a report** — professional HTML (print to PDF from the browser)
   with findings, entities, timeline, evidence table, chain of custody and
   an explicit Limitations section.

## API overview

| Method & path | Purpose |
|---|---|
| `POST /api/auth/login` | username/password (+ TOTP) → JWT |
| `POST /api/cases` | create case |
| `POST /api/collect/domain` | DNS + RDAP + CT certs + TLS |
| `POST /api/collect/ip` | IP intel + RDAP + AbuseIPDB + Shodan |
| `POST /api/collect/url` | website forensics + VirusTotal |
| `POST /api/collect/rdap` | RDAP for domain/IP/ASN |
| `POST /api/collect/tls` | live TLS certificate capture |
| `POST /api/collect/email?case_id=` | upload `.eml` (multipart) |
| `POST /api/collect/file?case_id=` | upload file evidence (multipart) |
| `GET /api/cases/{id}/evidence` | evidence list |
| `GET /api/evidence/{eid}` | detail + chain of custody (logs access) |
| `POST /api/evidence/{eid}/verify` | re-hash and verify integrity |
| `GET /api/cases/{id}/entities` | entity inventory |
| `GET /api/entities/{eid}` | entity + relationships + provenance |
| `GET /api/cases/{id}/graph` | nodes/edges for visualization |
| `GET /api/cases/{id}/timeline` | chronological events |
| `GET /api/search?q=` | cross-case authorized search |
| `POST /api/reports?case_id=` | generate HTML report |
| `POST /api/assistant/ask` | grounded Q&A over case evidence |
| `GET /api/system/sources` | connector + credential status |
| `GET /api/system/audit` | audit log (admin) |

Interactive docs: `/api/docs`.

## Evidence & provenance model

Every connector returns a standardized object:

```json
{ "source": "...", "target": "...", "collected_at": "...",
  "status": "OK", "raw_evidence": "<bytes>", "normalized": {...},
  "hash": "<sha256>", "errors": [] }
```

The vault stores `raw.bin`, `normalized.json` and `meta.json` under
`vault/data/<evidence-id>/`, records SHA-256, and appends a chain-of-custody
entry for every collect/access/export/verify action. `verify` re-hashes the
raw artifact — any tampering is detected and reported.

Relationships carry provenance: `OBSERVED` (directly seen),
`CORROBORATED`, `HISTORICAL` (source-reported past), `CORRELATED`
(linked, not proof), `INFERRED`, `UNVERIFIED`. The UI and reports render
these distinctly, and the forensic rule is enforced everywhere:

> Shared IP ≠ common ownership. Shared certificate ≠ common ownership.
> Same nameserver ≠ same organization. Correlation is not proof.

## Threat-intel keys (optional)

Without keys the connectors return `AUTHENTICATION_REQUIRED` with setup
instructions — they never return fake data.

```bash
export VIRUSTOTAL_API_KEY=... ABUSEIPDB_API_KEY=... SHODAN_API_KEY=...
export URLSCAN_API_KEY=... HIBP_API_KEY=...
```

Check status anytime: `GET /api/system/sources`.

## Forensic validation lab

```bash
pytest tests/ -v
```

18 tests cover: email header parsing, Received-chain chronology,
SPF/DKIM/DMARC reporting semantics, IOC extraction, attachment hashing,
DNS response decoding, file hashing, vault immutability + tamper detection,
chain of custody, DEV_FIXTURE isolation, report grounding, the no-mock
status vocabulary, and honest threat-intel degradation. **Run before every
release; a failing test means do not ship.**

`tests/e2e_verify.py` additionally exercises the live API end to end
(requires the server on :8123).

## Known limitations (by design)

- TLS connector captures the presented leaf certificate; full chain
  building is a documented future pass.
- `pcapng` and encrypted-file internals are out of scope for the triage
  connectors; use Wireshark/autopsy for deep dives.
- RDAP/TLS endpoints that reset non-browser TLS fingerprints use a
  curl fallback where available; otherwise the honest failure status is kept.
- Malware **must** be analyzed in isolated sandbox infrastructure —
  the file connector performs static analysis only and never executes uploads.
- Dark/deep-web collection is limited to lawful, publicly/authorized
  accessible sources; the platform records restrictions instead of
  bypassing them, and never implements credential theft, intrusion,
  exploitation or unauthorized access.
- The assistant is an evidence-grounded summarizer, not an oracle: it
  cannot see beyond collected evidence and will tell you so.

## Repository layout

```
wfip/
├── backend/wfip/        FastAPI app: models, auth, vault, pipeline,
│                        connectors/, routers/, reporting, assistant
├── backend/requirements.txt
├── frontend/            investigator dashboard (index.html, app.js, styles.css)
├── tests/               pytest validation lab + fixtures + e2e driver
├── docker/              Dockerfile, docker-compose.yml, .env.example, k8s.yaml
└── README.md
```
