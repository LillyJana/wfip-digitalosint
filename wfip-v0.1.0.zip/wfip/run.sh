#!/usr/bin/env bash
# WFIP quick launcher (development).
# Usage: ./run.sh  ->  http://127.0.0.1:8000  (admin / ChangeMe123!)
set -e
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  echo "Creating virtualenv..."
  python3 -m venv .venv
fi
.venv/bin/pip install -q -r backend/requirements.txt
cd backend
exec ../.venv/bin/python -m uvicorn wfip.main:app --host 127.0.0.1 --port 8000
