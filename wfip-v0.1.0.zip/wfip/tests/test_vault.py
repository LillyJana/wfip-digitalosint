"""Vault, chain-of-custody, report and no-mock-production tests."""

import hashlib
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from wfip import models  # noqa: E402
from wfip.auth import hash_password  # noqa: E402
from wfip.db import SessionLocal, init_db  # noqa: E402
from wfip.reporting import generate as generate_report  # noqa: E402
from wfip.vault import store_evidence, verify_evidence  # noqa: E402


@pytest.fixture()
def db(tmp_path, monkeypatch):
    import wfip.settings as settings_mod
    import wfip.vault as vault_mod
    import wfip.reporting as reporting_mod
    vault_dir = str(tmp_path / "vault")
    monkeypatch.setattr(settings_mod, "VAULT_DIR", vault_dir)
    monkeypatch.setattr(vault_mod, "VAULT_DIR", vault_dir)
    monkeypatch.setattr(reporting_mod, "REPORT_DIR",
                        os.path.join(vault_dir, "reports"))
    # re-init engine against the temp database
    import importlib
    import wfip.db as dbmod
    importlib.reload(settings_mod)
    monkeypatch.setattr(settings_mod, "VAULT_DIR", vault_dir)
    monkeypatch.setattr(vault_mod, "VAULT_DIR", vault_dir)
    dbmod.engine.dispose()
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    dbmod.engine = create_engine(f"sqlite:///{tmp_path}/t.db",
                                 connect_args={"check_same_thread": False})
    dbmod.SessionLocal = sessionmaker(bind=dbmod.engine)
    init_db()
    session = dbmod.SessionLocal()
    user = models.User(username="tester", password_hash=hash_password("x" * 13),
                       role="investigator")
    session.add(user)
    session.flush()
    case = models.Case(case_id="CASE-0001", title="Lab case")
    session.add(case)
    session.flush()
    yield session, user, case
    session.close()


def test_evidence_immutable_and_hashed(db):
    session, user, case = db
    raw = b"raw bytes v1"
    ev = store_evidence(session, case=case, collector="wfip/test",
                        target="t", source="lab", evidence_type="test",
                        raw=raw, normalized={"a": 1}, created_by=user)
    session.commit()
    assert ev.sha256 == hashlib.sha256(raw).hexdigest()
    assert ev.evidence_id.startswith("EV-")
    # raw artifact on disk matches
    with open(ev.raw_path, "rb") as fh:
        assert fh.read() == raw
    ok, msg = verify_evidence(ev)
    assert ok, msg
    # tamper -> verification must fail
    with open(ev.raw_path, "wb") as fh:
        fh.write(b"tampered")
    ok, msg = verify_evidence(ev)
    assert not ok and "MISMATCH" in msg


def test_chain_of_custody_recorded(db):
    session, user, case = db
    ev = store_evidence(session, case=case, collector="wfip/test",
                        target="t", source="lab", evidence_type="test",
                        raw=b"x", normalized={}, created_by=user)
    session.commit()
    events = session.query(models.CustodyEvent).filter_by(
        evidence_id=ev.id).all()
    assert any(e.action == "COLLECTED" and e.actor_name == "tester"
               for e in events)
    assert all(e.hash_at_time == ev.sha256 for e in events)


def test_dev_fixture_never_counts_as_production(db):
    session, user, case = db
    ev = store_evidence(session, case=case, collector="wfip/test",
                        target="t", source="lab", evidence_type="test",
                        raw=b"x", normalized={}, created_by=user,
                        dev_fixture=True)
    session.commit()
    assert ev.status == "DEV_FIXTURE"
    prod = session.query(models.Evidence).filter_by(
        case_id=case.id, status="COLLECTED").all()
    assert ev not in prod


def test_report_generation_grounded(db):
    session, user, case = db
    ev = store_evidence(session, case=case, collector="wfip/dns",
                        target="example.com", source="dns",
                        evidence_type="dns_records", raw=b"{}",
                        normalized={"A": ["93.184.216.34"]},
                        created_by=user)
    session.commit()
    rep = generate_report(session, case, user)
    assert rep["report_id"].startswith("RPT-")
    body = open(rep["path"], encoding="utf-8").read()
    # every finding references its evidence id
    assert ev.evidence_id in body
    assert ev.sha256 in body
    # limitations section always present
    assert "Limitations" in body
    assert "not proof of common ownership" in body


def test_no_mock_statuses_enumerated():
    from wfip.connectors import base
    for name in ("OK", "NOT_FOUND", "SOURCE_UNAVAILABLE", "ACCESS_RESTRICTED",
                 "AUTHENTICATION_REQUIRED", "COLLECTION_FAILED"):
        assert hasattr(base, name)


def test_threat_intel_without_keys_is_honest():
    import wfip.settings as settings
    settings.VIRUSTOTAL_API_KEY = ""
    settings.ABUSEIPDB_API_KEY = ""
    settings.SHODAN_API_KEY = ""
    import importlib
    import wfip.connectors.threat_intel as ti
    importlib.reload(ti)
    r = ti.virustotal_url("https://example.com")
    assert r["status"] == "AUTHENTICATION_REQUIRED"
    assert "VIRUSTOTAL_API_KEY" in r["errors"][0]
    r = ti.abuseipdb("8.8.8.8")
    assert r["status"] == "AUTHENTICATION_REQUIRED"
    r = ti.shodan_host("8.8.8.8")
    assert r["status"] == "AUTHENTICATION_REQUIRED"
