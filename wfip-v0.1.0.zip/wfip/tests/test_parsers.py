"""WFIP forensic validation lab.

Known fixtures with expected outputs. Run before every release:
    pytest tests/ -v

A failing test means the platform is NOT behaving like an
evidence-driven system and must not ship.
"""

import hashlib
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from wfip.connectors import dns as dns_conn  # noqa: E402
from wfip.connectors import email as email_conn  # noqa: E402
from wfip.connectors import file as file_conn  # noqa: E402

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


# ---------- email parser ----------

def test_email_headers_parsed():
    raw = open(os.path.join(FIXTURES, "phish.eml"), "rb").read()
    res = email_conn.parse(raw)
    assert res["status"] == "OK"
    n = res["normalized"]
    assert n["headers"]["From"] == ["Evil Sender <sender@evil.example>"]
    assert n["headers"]["To"] == ["victim@example.com"]
    assert n["headers"]["Cc"] == ["boss@example.com"]
    assert n["headers"]["Message-ID"] == ["<test123@evil.example>"]
    assert n["date_iso"].startswith("2026-10-03")


def test_email_received_chain_oldest_first():
    raw = open(os.path.join(FIXTURES, "phish.eml"), "rb").read()
    chain = email_conn.parse(raw)["normalized"]["received_chain"]
    assert len(chain) == 2
    # oldest hop first: the 192.0.2.55 submission
    assert chain[0]["ips"] == ["192.0.2.55"]
    assert chain[0]["by"] == "mail.evil.example"
    assert chain[1]["ips"] == ["203.0.113.10"]
    assert chain[1]["by"] == "mx.example.com"
    assert chain[0]["date"] < chain[1]["date"]


def test_email_auth_results_reported_not_invented():
    raw = open(os.path.join(FIXTURES, "phish.eml"), "rb").read()
    authr = email_conn.parse(raw)["normalized"]["authentication_results"]
    assert len(authr) == 1
    assert authr[0]["spf"] == "fail"
    assert authr[0]["dkim"] == "fail"
    assert authr[0]["dmarc"] == "fail"
    summary = email_conn.parse(raw)["normalized"]["auth_summary"]["note"]
    assert "as reported" in summary  # must not claim proven authorship


def test_email_iocs_extracted():
    raw = open(os.path.join(FIXTURES, "phish.eml"), "rb").read()
    n = email_conn.parse(raw)["normalized"]
    assert "https://evil.example/invoice/123" in n["urls"]
    assert "evil.example" in n["domains"]
    assert "203.0.113.99" in n["ips_in_body"]
    assert "mx.example.com" in n["mail_servers"]


def test_email_attachment_preserved_with_hash():
    raw = open(os.path.join(FIXTURES, "phish.eml"), "rb").read()
    n = email_conn.parse(raw)["normalized"]
    assert len(n["attachments"]) == 1
    att = n["attachments"][0]
    assert att["filename"] == "invoice.pdf"
    assert att["sha256"] == hashlib.sha256(b"Hello evil").hexdigest()
    # original bytes preserved verbatim
    res = email_conn.parse(raw)
    assert res["raw_evidence"] == raw
    assert res["hash"] == hashlib.sha256(raw).hexdigest()


def test_email_garbage_fails_honestly():
    res = email_conn.parse(b"\xff\xfe\x00not-an-email-at-all\x00\x01")
    # must parse-or-fail honestly, never invent headers
    assert res["status"] in ("OK", "COLLECTION_FAILED")
    if res["status"] == "OK":
        assert res["normalized"]["headers"].get("From") is None


# ---------- DNS parsing (offline: response decoder) ----------

def _build_dns_response():
    import random
    import struct
    qid = 0x1234
    qname = b"\x07example\x03com\x00"
    question = qname + struct.pack(">HH", 1, 1)
    header = struct.pack(">HHHHHH", qid, 0x8180, 1, 1, 0, 0)
    # answer: pointer to qname, A 93.184.216.34
    answer = (b"\xc0\x0c" + struct.pack(">HHIH", 1, 1, 300, 4)
              + bytes([93, 184, 216, 34]))
    return header + question + answer, 12 + len(question)


def test_dns_response_decoder():
    data, qlen = _build_dns_response()
    answers = dns_conn._parse_response(data, qlen)
    assert answers == ["93.184.216.34"]


def test_dns_txt_decoder():
    import struct
    qid = 0x1234
    qname = b"\x07example\x03com\x00"
    question = qname + struct.pack(">HH", 16, 1)
    header = struct.pack(">HHHHHH", qid, 0x8180, 1, 1, 0, 0)
    txt = b"v=spf1 -all"
    rdata = bytes([len(txt)]) + txt
    answer = b"\xc0\x0c" + struct.pack(">HHIH", 16, 1, 300, len(rdata)) + rdata
    answers = dns_conn._parse_response(header + question + answer, 12 + len(question))
    assert answers == ["v=spf1 -all"]


def test_dns_key_tag_rfc4034():
    # RFC 4034 Appendix B example key tag = 60485
    rdata = bytes.fromhex(
        "010100030100a1d2d90000002a0000001e0000007800"
        "0102030405060708090a0b0c0d0e0f")
    # use a synthetic DNSKEY rdata; just verify function runs deterministically
    assert dns_conn._key_tag(rdata) == dns_conn._key_tag(rdata)
    assert 0 <= dns_conn._key_tag(rdata) <= 65535


# ---------- file forensics ----------

def test_file_hashes_known():
    p = os.path.join(FIXTURES, "hello.txt")
    with open(p, "wb") as fh:
        fh.write(b"hello evidence\n")
    res = file_conn.collect(p)
    assert res["status"] == "OK"
    n = res["normalized"]
    assert n["sha256"] == hashlib.sha256(b"hello evidence\n").hexdigest()
    assert n["sha1"] == hashlib.sha1(b"hello evidence\n").hexdigest()
    assert n["md5"] == hashlib.md5(b"hello evidence\n").hexdigest()
    assert n["static_analysis_only"] is True


def test_file_iocs_bounded():
    p = os.path.join(FIXTURES, "hello.txt")
    with open(p, "wb") as fh:
        fh.write(b"contact https://c2.example/x and 10.9.9.9 now\n")
    n = file_conn.collect(p)["normalized"]
    assert "https://c2.example/x" in n["indicators"]["urls"]
    assert "10.9.9.9" in n["indicators"]["ips"]


def test_file_missing_fails_honestly():
    res = file_conn.collect("/nonexistent/wfip-test-file")
    assert res["status"] == "COLLECTION_FAILED"
    assert res["normalized"] == {}
