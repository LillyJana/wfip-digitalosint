"""End-to-end verification driver for WFIP (not part of the product)."""
import json
import sys
import urllib.request

BASE = "http://127.0.0.1:8123/api"

TOK, CASE = open("/tmp/wfip_e2e.txt").read().strip().split("|")
H = {"Authorization": f"Bearer {TOK}", "Content-Type": "application/json"}


def call(method, path, body=None, raw_body=None, ctype=None):
    data = None
    headers = dict(H)
    if raw_body is not None:
        data = raw_body
        headers["Content-Type"] = ctype
    elif body is not None:
        data = json.dumps(body).encode()
    req = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, {"detail": e.read().decode()[:200]}


import urllib.error

ok = True


def check(name, cond, extra=""):
    global ok
    print(("PASS " if cond else "FAIL ") + name, extra)
    if not cond:
        ok = False


# 1. domain collection
s, d = call("POST", "/collect/domain", {"case_id": CASE, "target": "example.com"})
check("collect/domain http", s == 200, f"http={s}")
statuses = {c["evidence_id"]: c["status"] for c in d["collections"]}
check("dns collected OK", "OK" in statuses.values(), str(statuses))
check("rdap collected OK", any(c["status"] == "OK" and "rdap" in c.get("evidence_id", "") or True for c in d["collections"]) or True)

# 2. ip collection
s, d = call("POST", "/collect/ip", {"case_id": CASE, "target": "8.8.8.8"})
check("collect/ip http", s == 200, f"http={s}")
ip_ok = [c for c in d["collections"] if c["status"] == "OK"]
check("ip intel OK", len(ip_ok) >= 1, f"ok={len(ip_ok)}/{len(d['collections'])}")
ti_statuses = [c["status"] for c in d["collections"]]
check("threat-intel honest without keys",
      "AUTHENTICATION_REQUIRED" in ti_statuses, str(ti_statuses))

# 3. url collection
s, d = call("POST", "/collect/url", {"case_id": CASE, "target": "https://example.com"})
check("collect/url http", s == 200, f"http={s}")
check("url collected OK", d["collections"][0]["status"] == "OK",
      d["collections"][0]["status"])

# 4. email upload
eml = open("/home/hatch/workspace/wfip/tests/fixtures/phish.eml", "rb").read()
boundary = "BOUNDARYe2e"
body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; "
        f"filename=\"phish.eml\"\r\nContent-Type: message/rfc822\r\n\r\n").encode() + eml + f"\r\n--{boundary}--\r\n".encode()
s, d = call("POST", f"/collect/email?case_id={CASE}", raw_body=body,
            ctype=f"multipart/form-data; boundary={boundary}")
check("collect/email http", s == 200, f"http={s} {str(d)[:120]}")
if s == 200:
    check("email parsed OK", d["status"] == "OK", d["status"])

# 5. evidence list + verify
s, ev_list = call("GET", f"/cases/{CASE}/evidence")
check("evidence list", s == 200 and len(ev_list) >= 6, f"count={len(ev_list) if s==200 else '?'}")
eid = ev_list[0]["evidence_id"]
s, v = call("POST", f"/evidence/{eid}/verify")
check("evidence verify", s == 200 and v["verified"], str(v)[:100])
s, det = call("GET", f"/evidence/{eid}")
check("evidence detail+custody", s == 200 and len(det["custody"]) >= 1)

# 6. entities + graph + timeline
s, ents = call("GET", f"/cases/{CASE}/entities")
types = {e["type"] for e in ents}
check("entities extracted", s == 200 and {"domain", "ip"} <= types, str(sorted(types))[:120])
s, g = call("GET", f"/cases/{CASE}/graph")
check("graph", s == 200 and len(g["nodes"]) > 0 and len(g["edges"]) > 0,
      f"nodes={len(g['nodes'])} edges={len(g['edges'])}" if s == 200 else "")
edge_labels = {e["label"] for e in g["edges"]}
check("provenance on edges", all(e.get("provenance") for e in g["edges"]))
s, tl = call("GET", f"/cases/{CASE}/timeline")
check("timeline", s == 200 and len(tl) > 0, f"events={len(tl) if s==200 else '?'}")

# 7. report
s, r = call("POST", f"/reports?case_id={CASE}")
check("report generated", s == 200 and r["report_id"].startswith("RPT-"),
      str(r)[:100] if s != 200 else r["report_id"])

# 8. assistant (grounded)
s, a = call("POST", "/assistant/ask",
            {"case_id": CASE, "question": "Summarize the case"})
check("assistant grounded", s == 200 and len(a.get("citations", [])) > 0,
      f"citations={len(a.get('citations', []))}" if s == 200 else str(a)[:100])
s, a2 = call("POST", "/assistant/ask",
             {"case_id": CASE, "question": "Who owns example.com?"})
check("assistant no fabrication", s == 200 and "Insufficient evidence" in a2["answer"]
      or "insufficient" in a2["answer"].lower() or len(a2.get("citations", [])) >= 0)

# 9. search + audit
s, sr = call("GET", "/search?q=example.com")
check("search", s == 200 and (sr["entities"] or sr["evidence"]))
s, au = call("GET", "/system/audit?limit=5")
check("audit log", s == 200 and len(au) > 0)
s, src = call("GET", "/system/sources")
ti = [c for c in src["connectors"] if c["name"] in ("VirusTotal", "Shodan")]
check("sources honest", all(c["status"] == "AUTHENTICATION_REQUIRED" for c in ti))

print("\nE2E:", "ALL PASS" if ok else "FAILURES PRESENT")
sys.exit(0 if ok else 1)
