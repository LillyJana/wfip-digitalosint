"""Evidence, entities, graph, timeline, search endpoints."""

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from .. import models
from ..auth import get_current_user, require_case_access
from ..db import get_db
from ..vault import add_custody_event, audit, verify_evidence

router = APIRouter(tags=["investigation"])


def _case(db, case_id, user):
    case = db.query(models.Case).filter(
        (models.Case.id == case_id) | (models.Case.case_id == case_id)).first()
    if not case:
        raise HTTPException(404, "Case not found")
    require_case_access(db, user, case)
    return case


def _ev(db, evidence_id, user):
    ev = db.query(models.Evidence).filter(
        (models.Evidence.id == evidence_id) |
        (models.Evidence.evidence_id == evidence_id)).first()
    if not ev:
        raise HTTPException(404, "Evidence not found")
    case = db.get(models.Case, ev.case_id)
    require_case_access(db, user, case)
    return ev


def _ev_serialize(ev):
    return {
        "id": ev.id, "evidence_id": ev.evidence_id, "case_id": ev.case_id,
        "collector": ev.collector, "collector_version": ev.collector_version,
        "target": ev.target, "source": ev.source,
        "evidence_type": ev.evidence_type, "status": ev.status,
        "collection_status": ev.collection_status,
        "collected_at": ev.collected_at.isoformat(), "sha256": ev.sha256,
        "errors": ev.errors, "normalized": ev.normalized,
    }


@router.get("/cases/{case_id}/evidence")
def list_evidence(case_id: str, db: Session = Depends(get_db),
                  user: models.User = Depends(get_current_user)):
    case = _case(db, case_id, user)
    items = db.query(models.Evidence).filter_by(case_id=case.id).order_by(
        models.Evidence.collected_at.desc()).all()
    return [_ev_serialize(e) for e in items]


@router.get("/evidence/{evidence_id}")
def get_evidence(evidence_id: str, db: Session = Depends(get_db),
                 user: models.User = Depends(get_current_user)):
    ev = _ev(db, evidence_id, user)
    add_custody_event(db, ev, actor=user, action="ACCESSED",
                     reason="evidence viewed via API")
    audit(db, actor=user, action="EVIDENCE_VIEW", target_type="evidence",
          target_id=ev.evidence_id)
    db.commit()
    data = _ev_serialize(ev)
    data["custody"] = [
        {"actor": c.actor_name, "action": c.action, "reason": c.reason,
         "hash_at_time": c.hash_at_time, "timestamp": c.timestamp.isoformat()}
        for c in db.query(models.CustodyEvent).filter_by(
            evidence_id=ev.id).order_by(models.CustodyEvent.timestamp)]
    return data


@router.get("/evidence/{evidence_id}/raw")
def download_raw(evidence_id: str, db: Session = Depends(get_db),
                 user: models.User = Depends(get_current_user)):
    ev = _ev(db, evidence_id, user)
    add_custody_event(db, ev, actor=user, action="EXPORTED",
                     reason="raw artifact downloaded")
    audit(db, actor=user, action="EVIDENCE_EXPORT", target_type="evidence",
          target_id=ev.evidence_id)
    db.commit()
    return FileResponse(ev.raw_path, filename=f"{ev.evidence_id}.bin")


@router.post("/evidence/{evidence_id}/verify")
def verify(evidence_id: str, db: Session = Depends(get_db),
           user: models.User = Depends(get_current_user)):
    ev = _ev(db, evidence_id, user)
    ok, message = verify_evidence(ev)
    add_custody_event(db, ev, actor=user, action="VERIFIED", reason=message)
    audit(db, actor=user, action="EVIDENCE_VERIFY", target_type="evidence",
          target_id=ev.evidence_id, detail=message)
    db.commit()
    return {"evidence_id": ev.evidence_id, "verified": ok, "message": message}


@router.get("/cases/{case_id}/entities")
def list_entities(case_id: str, type: str | None = None,
                   db: Session = Depends(get_db),
                   user: models.User = Depends(get_current_user)):
    case = _case(db, case_id, user)
    q = db.query(models.Entity).filter_by(case_id=case.id)
    if type:
        q = q.filter_by(type=type)
    return [{"entity_id": e.entity_id, "type": e.type, "value": e.value,
             "attributes": e.attributes,
             "first_seen": e.first_seen.isoformat(),
             "last_seen": e.last_seen.isoformat()}
            for e in q.order_by(models.Entity.last_seen.desc()).limit(500)]


@router.get("/entities/{entity_id}")
def get_entity(entity_id: str, db: Session = Depends(get_db),
               user: models.User = Depends(get_current_user)):
    ent = db.query(models.Entity).filter(
        (models.Entity.id == entity_id) |
        (models.Entity.entity_id == entity_id)).first()
    if not ent:
        raise HTTPException(404, "Entity not found")
    case = db.get(models.Case, ent.case_id)
    require_case_access(db, user, case)
    rels = db.query(models.Relationship).filter(
        (models.Relationship.from_entity_id == ent.id) |
        (models.Relationship.to_entity_id == ent.id)).all()
    out_rels = []
    for r in rels:
        other = db.get(models.Entity,
                       r.to_entity_id if r.from_entity_id == ent.id else r.from_entity_id)
        ev = db.get(models.Evidence, r.evidence_id) if r.evidence_id else None
        out_rels.append({
            "direction": "out" if r.from_entity_id == ent.id else "in",
            "rel_type": r.rel_type, "provenance": r.provenance,
            "detail": r.detail,
            "entity": {"entity_id": other.entity_id, "type": other.type,
                       "value": other.value},
            "evidence_id": ev.evidence_id if ev else None,
        })
    return {"entity_id": ent.entity_id, "type": ent.type, "value": ent.value,
            "attributes": ent.attributes, "relationships": out_rels}


@router.get("/cases/{case_id}/graph")
def get_graph(case_id: str, db: Session = Depends(get_db),
              user: models.User = Depends(get_current_user)):
    case = _case(db, case_id, user)
    entities = db.query(models.Entity).filter_by(case_id=case.id).limit(500).all()
    by_id = {e.id: e for e in entities}
    rels = db.query(models.Relationship).filter_by(case_id=case.id).all()
    nodes = [{"id": e.entity_id, "type": e.type, "value": e.value[:80]} for e in entities]
    edges = []
    for r in rels:
        if r.from_entity_id in by_id and r.to_entity_id in by_id:
            ev = db.get(models.Evidence, r.evidence_id) if r.evidence_id else None
            edges.append({
                "from": by_id[r.from_entity_id].entity_id,
                "to": by_id[r.to_entity_id].entity_id,
                "label": r.rel_type, "provenance": r.provenance,
                "detail": r.detail,
                "evidence_id": ev.evidence_id if ev else None,
            })
    return {"nodes": nodes, "edges": edges}


@router.get("/cases/{case_id}/timeline")
def get_timeline(case_id: str, db: Session = Depends(get_db),
                 user: models.User = Depends(get_current_user)):
    case = _case(db, case_id, user)
    events = db.query(models.TimelineEvent).filter_by(case_id=case.id).order_by(
        models.TimelineEvent.timestamp).all()
    out = []
    for t in events:
        ev = db.get(models.Evidence, t.evidence_id) if t.evidence_id else None
        out.append({
            "timestamp": t.timestamp.isoformat(), "event_type": t.event_type,
            "target": t.target, "source": t.source,
            "evidence_id": ev.evidence_id if ev else None,
            "classification": t.classification, "detail": t.detail,
        })
    return out


@router.get("/search")
def search(q: str = Query(..., min_length=2), db: Session = Depends(get_db),
           user: models.User = Depends(get_current_user)):
    pattern = f"%{q}%"
    # Case-level authorization: only cases the user can access.
    if user.role == "admin":
        case_ids = [c.id for c in db.query(models.Case).all()]
    else:
        member_ids = [m.case_id for m in
                      db.query(models.CaseMember).filter_by(user_id=user.id)]
        owned = [c.id for c in db.query(models.Case).filter_by(created_by=user.id)]
        case_ids = list(set(member_ids + owned))
    entities = db.query(models.Entity).filter(
        models.Entity.case_id.in_(case_ids),
        models.Entity.value.like(pattern)).limit(50).all()
    evidence = db.query(models.Evidence).filter(
        models.Evidence.case_id.in_(case_ids),
        (models.Evidence.target.like(pattern) |
         models.Evidence.evidence_id.like(pattern) |
         models.Evidence.sha256.like(pattern))).limit(50).all()
    audit(db, actor=user, action="SEARCH", detail=f"q={q}")
    db.commit()
    return {
        "entities": [{"entity_id": e.entity_id, "type": e.type, "value": e.value,
                      "case_id": e.case_id} for e in entities],
        "evidence": [{"evidence_id": e.evidence_id, "target": e.target,
                      "sha256": e.sha256, "case_id": e.case_id} for e in evidence],
    }
