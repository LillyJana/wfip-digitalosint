"""Reports, AI assistant, and system endpoints."""

import os

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..assistant_engine import answer as assistant_answer
from ..assistant_engine import explain_evidence
from ..auth import get_current_user, require_case_access, require_role
from ..db import get_db
from ..reporting import generate as generate_report
from ..settings import (ABUSEIPDB_API_KEY, DEV_MODE, EPHEMERAL_JWT,
                        HIBP_API_KEY, SHODAN_API_KEY, URLSCAN_API_KEY,
                        VIRUSTOTAL_API_KEY)
from ..vault import audit

reports_router = APIRouter(prefix="/reports", tags=["reports"])
assistant_router = APIRouter(prefix="/assistant", tags=["assistant"])
system_router = APIRouter(prefix="/system", tags=["system"])


def _case(db, case_id, user):
    case = db.query(models.Case).filter(
        (models.Case.id == case_id) | (models.Case.case_id == case_id)).first()
    if not case:
        raise HTTPException(404, "Case not found")
    require_case_access(db, user, case)
    return case


# ---- reports ----

@reports_router.post("")
def create_report(case_id: str, db: Session = Depends(get_db),
                  user: models.User = Depends(get_current_user)):
    case = _case(db, case_id, user)
    result = generate_report(db, case, user)
    audit(db, actor=user, action="REPORT_GENERATE", target_type="case",
          target_id=case.case_id, detail=result["report_id"])
    db.commit()
    return result


@reports_router.get("")
def list_reports(case_id: str, db: Session = Depends(get_db),
                 user: models.User = Depends(get_current_user)):
    case = _case(db, case_id, user)
    reps = db.query(models.Report).filter_by(case_id=case.id).order_by(
        models.Report.created_at.desc()).all()
    return [{"report_id": r.report_id, "title": r.title, "sha256": r.sha256,
             "evidence_count": r.evidence_count,
             "created_at": r.created_at.isoformat()} for r in reps]


@reports_router.get("/{report_id}")
def download_report(report_id: str, db: Session = Depends(get_db),
                    user: models.User = Depends(get_current_user)):
    rep = db.query(models.Report).filter_by(report_id=report_id).first()
    if not rep:
        raise HTTPException(404, "Report not found")
    case = db.get(models.Case, rep.case_id)
    require_case_access(db, user, case)
    audit(db, actor=user, action="REPORT_VIEW", target_type="report",
          target_id=report_id)
    db.commit()
    return FileResponse(rep.path, media_type="text/html",
                        filename=f"{report_id}.html")


# ---- assistant ----

class AskRequest(BaseModel):
    case_id: str
    question: str


@assistant_router.post("/ask")
def ask(payload: AskRequest, db: Session = Depends(get_db),
        user: models.User = Depends(get_current_user)):
    case = _case(db, payload.case_id, user)
    result = assistant_answer(db, case, payload.question)
    audit(db, actor=user, action="ASSISTANT_ASK", target_type="case",
          target_id=case.case_id, detail=payload.question[:200])
    db.commit()
    result["grounding"] = ("Every factual statement above is derived from "
                           "evidence stored for this case. 'Insufficient "
                           "evidence to establish this finding.' means exactly that.")
    return result


@assistant_router.get("/explain/{evidence_id}")
def explain(evidence_id: str, db: Session = Depends(get_db),
            user: models.User = Depends(get_current_user)):
    ev = db.query(models.Evidence).filter(
        (models.Evidence.id == evidence_id) |
        (models.Evidence.evidence_id == evidence_id)).first()
    if not ev:
        raise HTTPException(404, "Evidence not found")
    case = db.get(models.Case, ev.case_id)
    require_case_access(db, user, case)
    return explain_evidence(db, ev)


# ---- system ----

@system_router.get("/health")
def health(db: Session = Depends(get_db)):
    return {"status": "ok", "dev_mode": DEV_MODE,
            "ephemeral_jwt_secret": EPHEMERAL_JWT,
            "evidence_total": db.query(models.Evidence).count(),
            "cases_total": db.query(models.Case).count()}


@system_router.get("/sources")
def sources(user: models.User = Depends(get_current_user)):
    def key_state(value, name, url):
        return {"name": name,
                "status": "CONFIGURED" if value else "AUTHENTICATION_REQUIRED",
                "setup": url if not value else ""}
    return {
        "connectors": [
            {"name": "RDAP", "collector": "wfip/rdap",
             "status": "READY", "credentials": "none required"},
            {"name": "DNS", "collector": "wfip/dns",
             "status": "READY", "credentials": "none required"},
            {"name": "HTTP/Website", "collector": "wfip/http",
             "status": "READY", "credentials": "none required"},
            {"name": "TLS", "collector": "wfip/tls",
             "status": "READY", "credentials": "none required"},
            {"name": "Certificates (CT)", "collector": "wfip/certificates",
             "status": "READY", "credentials": "none required"},
            {"name": "Email parser", "collector": "wfip/email",
             "status": "READY", "credentials": "none required"},
            {"name": "IP intel", "collector": "wfip/ip",
             "status": "READY", "credentials": "none required"},
            {"name": "File forensics", "collector": "wfip/file",
             "status": "READY", "credentials": "none required"},
            key_state(VIRUSTOTAL_API_KEY, "VirusTotal",
                      "Set VIRUSTOTAL_API_KEY (https://www.virustotal.com/gui/my-apikey)"),
            key_state(ABUSEIPDB_API_KEY, "AbuseIPDB",
                      "Set ABUSEIPDB_API_KEY (https://www.abuseipdb.com/account/api)"),
            key_state(SHODAN_API_KEY, "Shodan",
                      "Set SHODAN_API_KEY (https://account.shodan.io/)"),
            key_state(URLSCAN_API_KEY, "urlscan.io",
                      "Set URLSCAN_API_KEY (https://urlscan.io/user/profile/)"),
            key_state(HIBP_API_KEY, "HaveIBeenPwned",
                      "Set HIBP_API_KEY (https://haveibeenpwned.com/API/v3)"),
        ],
        "policy": "Connectors without credentials report AUTHENTICATION_REQUIRED. "
                  "No connector fabricates data.",
    }


@system_router.get("/audit")
def audit_log(limit: int = 100, db: Session = Depends(get_db),
              user: models.User = Depends(require_role("admin"))):
    rows = db.query(models.AuditLog).order_by(
        models.AuditLog.timestamp.desc()).limit(min(limit, 1000)).all()
    return [{"timestamp": r.timestamp.isoformat(), "actor": r.actor_name,
             "action": r.action, "target_type": r.target_type,
             "target_id": r.target_id, "detail": r.detail, "ip": r.ip}
            for r in rows]


@system_router.get("/users")
def list_users(db: Session = Depends(get_db),
               user: models.User = Depends(require_role("admin"))):
    return [{"username": u.username, "role": u.role, "active": u.active,
             "mfa_enabled": u.totp_enabled} for u in db.query(models.User).all()]
