"""Collection endpoints: run connectors, store evidence, build the graph."""

import os
import tempfile

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..auth import get_current_user, require_case_access, require_min_role
from ..connectors import certificates, dns, email as email_conn
from ..connectors import file as file_conn
from ..connectors import http as http_conn
from ..connectors import ip as ip_conn
from ..connectors import rdap, threat_intel, tls
from ..db import get_db
from ..pipeline import extract
from ..settings import DEV_MODE
from ..vault import audit, store_evidence

router = APIRouter(prefix="/collect", tags=["collect"])


class CollectRequest(BaseModel):
    case_id: str
    target: str


def _get_case(db, case_id, user):
    case = db.query(models.Case).filter(
        (models.Case.id == case_id) | (models.Case.case_id == case_id)).first()
    if not case:
        raise HTTPException(404, "Case not found")
    require_case_access(db, user, case)
    return case


def _ingest(db, case, user, res, kind, evidence_type):
    """Store one connector result as evidence and run entity extraction."""
    ev = store_evidence(
        db, case=case, collector=res["collector"], target=res["target"],
        source=res["source"], evidence_type=evidence_type,
        raw=res["raw_evidence"], normalized=res["normalized"],
        collection_status=res["status"], errors=res["errors"],
        created_by=user, dev_fixture=False)
    extract(db, case, ev, res)
    job = models.CollectionJob(case_id=case.id, kind=kind, target=res["target"],
                               status="DONE" if res["status"] == "OK" else "FAILED",
                               evidence_ids=[ev.evidence_id],
                               error="; ".join(res["errors"]),
                               created_by=user.id)
    db.add(job)
    audit(db, actor=user, action="COLLECT", target_type="evidence",
          target_id=ev.evidence_id,
          detail=f"{res['collector']} target={res['target']} status={res['status']}")
    db.commit()
    return {
        "job_id": job.id,
        "evidence_id": ev.evidence_id,
        "status": res["status"],
        "sha256": ev.sha256,
        "errors": res["errors"],
        "normalized": res["normalized"],
    }


def _dev_guard():
    if DEV_MODE:
        raise HTTPException(400, "DEV fixtures disabled on this endpoint in production mode")


@router.post("/domain")
def collect_domain(payload: CollectRequest, db: Session = Depends(get_db),
                   user: models.User = Depends(require_min_role("investigator"))):
    case = _get_case(db, payload.case_id, user)
    domain = payload.target.strip().lower().rstrip(".")
    results = []
    for res, etype in (
            (dns.collect(domain), "dns_records"),
            (rdap.collect_domain(domain), "rdap"),
            (certificates.collect(domain), "certificates")):
        results.append(_ingest(db, case, user, res, "domain", etype))
    # TLS on the domain itself
    tls_res = tls.collect(domain)
    results.append(_ingest(db, case, user, tls_res, "domain", "tls_certificate"))
    return {"target": domain, "collections": results}


@router.post("/ip")
def collect_ip(payload: CollectRequest, db: Session = Depends(get_db),
               user: models.User = Depends(require_min_role("investigator"))):
    case = _get_case(db, payload.case_id, user)
    results = [
        _ingest(db, case, user, ip_conn.collect(payload.target), "ip", "ip_intel"),
        _ingest(db, case, user, rdap.collect_ip(payload.target), "ip", "rdap"),
    ]
    ti = threat_intel.abuseipdb(payload.target)
    results.append(_ingest(db, case, user, ti, "ip", "threat_intel"))
    shodan = threat_intel.shodan_host(payload.target)
    results.append(_ingest(db, case, user, shodan, "ip", "threat_intel"))
    return {"target": payload.target, "collections": results}


@router.post("/url")
def collect_url(payload: CollectRequest, db: Session = Depends(get_db),
                user: models.User = Depends(require_min_role("investigator"))):
    case = _get_case(db, payload.case_id, user)
    results = [_ingest(db, case, user, http_conn.collect(payload.target), "url", "website")]
    vt = threat_intel.virustotal_url(payload.target)
    results.append(_ingest(db, case, user, vt, "url", "threat_intel"))
    return {"target": payload.target, "collections": results}


@router.post("/rdap")
def collect_rdap(payload: CollectRequest, db: Session = Depends(get_db),
                 user: models.User = Depends(require_min_role("investigator"))):
    case = _get_case(db, payload.case_id, user)
    target = payload.target.strip()
    if target.upper().startswith("AS"):
        res = rdap.collect_asn(target)
    elif "." in target and not target.replace(".", "").replace(":", "").isdigit():
        # crude domain vs ip distinction
        try:
            import ipaddress
            ipaddress.ip_address(target)
            res = rdap.collect_ip(target)
        except ValueError:
            res = rdap.collect_domain(target)
    else:
        res = rdap.collect_ip(target)
    return _ingest(db, case, user, res, "rdap", "rdap")


@router.post("/tls")
def collect_tls(payload: CollectRequest, db: Session = Depends(get_db),
                user: models.User = Depends(require_min_role("investigator"))):
    case = _get_case(db, payload.case_id, user)
    res = tls.collect(payload.target)
    return _ingest(db, case, user, res, "tls", "tls_certificate")


@router.post("/email")
async def collect_email(case_id: str, file: UploadFile = File(...),
                        db: Session = Depends(get_db),
                        user: models.User = Depends(require_min_role("investigator"))):
    case = _get_case(db, case_id, user)
    raw = await file.read()
    if len(raw) > 50 * 1024 * 1024:
        raise HTTPException(400, "Email file too large (50 MB limit)")
    res = email_conn.parse(raw)
    res["target"] = file.filename or "uploaded.eml"
    return _ingest(db, case, user, res, "email", "email")


@router.post("/file")
async def collect_file(case_id: str, file: UploadFile = File(...),
                       db: Session = Depends(get_db),
                       user: models.User = Depends(require_min_role("investigator"))):
    case = _get_case(db, case_id, user)
    # Stream upload to a temp file - never execute, static analysis only.
    with tempfile.NamedTemporaryFile(delete=False,
                                     suffix="_" + (file.filename or "evidence")) as tmp:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            tmp.write(chunk)
        tmp_path = tmp.name
    try:
        res = file_conn.collect(tmp_path)
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
    res["target"] = file.filename or "uploaded file"
    return _ingest(db, case, user, res, "file", "file")


@router.get("/jobs/{job_id}")
def get_job(job_id: str, db: Session = Depends(get_db),
            user: models.User = Depends(get_current_user)):
    job = db.get(models.CollectionJob, job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    case = db.get(models.Case, job.case_id)
    require_case_access(db, user, case)
    return {"id": job.id, "kind": job.kind, "target": job.target,
            "status": job.status, "evidence_ids": job.evidence_ids,
            "error": job.error, "created_at": job.created_at.isoformat()}
