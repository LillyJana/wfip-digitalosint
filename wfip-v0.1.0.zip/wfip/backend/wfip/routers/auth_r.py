"""Authentication endpoints: login, MFA, user management."""

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..auth import (create_token, get_current_user, hash_password, new_totp_secret,
                    require_role, totp_code, verify_password, verify_totp)
from ..db import get_db
from ..vault import audit

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str
    password: str
    totp_code: str | None = None


class UserCreate(BaseModel):
    username: str
    password: str
    role: str = "investigator"


class PasswordChange(BaseModel):
    old_password: str
    new_password: str


@router.post("/login")
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    user = db.query(models.User).filter_by(username=payload.username).first()
    ip = request.client.host if request.client else ""
    if not user or not user.active or not verify_password(payload.password, user.password_hash):
        audit(db, actor=None, action="LOGIN_FAILED", detail=payload.username, ip=ip)
        db.commit()
        raise HTTPException(401, "Invalid credentials")
    if user.totp_enabled:
        if not payload.totp_code or not verify_totp(user.totp_secret, payload.totp_code):
            audit(db, actor=user, action="LOGIN_MFA_FAILED", ip=ip)
            db.commit()
            raise HTTPException(401, "MFA code required or invalid")
    token = create_token(user)
    audit(db, actor=user, action="LOGIN", ip=ip)
    db.commit()
    return {"access_token": token, "token_type": "bearer",
            "username": user.username, "role": user.role,
            "mfa_enabled": user.totp_enabled}


@router.get("/me")
def me(user: models.User = Depends(get_current_user)):
    return {"username": user.username, "role": user.role,
            "mfa_enabled": user.totp_enabled}


@router.post("/users")
def create_user(payload: UserCreate, db: Session = Depends(get_db),
                admin: models.User = Depends(require_role("admin"))):
    if db.query(models.User).filter_by(username=payload.username).first():
        raise HTTPException(400, "Username already exists")
    if payload.role not in ("admin", "investigator", "viewer"):
        raise HTTPException(400, "Invalid role")
    user = models.User(username=payload.username,
                       password_hash=hash_password(payload.password),
                       role=payload.role)
    db.add(user)
    audit(db, actor=admin, action="USER_CREATE", target_type="user",
          target_id=payload.username, detail=f"role={payload.role}")
    db.commit()
    return {"username": user.username, "role": user.role}


@router.post("/mfa/setup")
def mfa_setup(db: Session = Depends(get_db),
              user: models.User = Depends(get_current_user)):
    if not user.totp_secret:
        user.totp_secret = new_totp_secret()
        db.commit()
    # otpauth URI for authenticator apps
    uri = (f"otpauth://totp/WFIP:{user.username}"
           f"?secret={user.totp_secret}&issuer=WFIP")
    return {"secret": user.totp_secret, "otpauth_uri": uri,
            "enabled": user.totp_enabled}


class MfaVerify(BaseModel):
    code: str


@router.post("/mfa/enable")
def mfa_enable(payload: MfaVerify, db: Session = Depends(get_db),
               user: models.User = Depends(get_current_user)):
    if not user.totp_secret or not verify_totp(user.totp_secret, payload.code):
        raise HTTPException(400, "Invalid code")
    user.totp_enabled = True
    audit(db, actor=user, action="MFA_ENABLED")
    db.commit()
    return {"ok": True}


@router.post("/mfa/disable")
def mfa_disable(payload: MfaVerify, db: Session = Depends(get_db),
                user: models.User = Depends(get_current_user)):
    if not verify_totp(user.totp_secret or "", payload.code):
        raise HTTPException(400, "Invalid code")
    user.totp_enabled = False
    audit(db, actor=user, action="MFA_DISABLED")
    db.commit()
    return {"ok": True}


@router.post("/password")
def change_password(payload: PasswordChange, db: Session = Depends(get_db),
                    user: models.User = Depends(get_current_user)):
    if not verify_password(payload.old_password, user.password_hash):
        raise HTTPException(400, "Current password incorrect")
    if len(payload.new_password) < 12:
        raise HTTPException(400, "New password must be at least 12 characters")
    user.password_hash = hash_password(payload.new_password)
    audit(db, actor=user, action="PASSWORD_CHANGE")
    db.commit()
    return {"ok": True}
