"""Case management: CRUD, membership, notes."""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..auth import (can_access_case, get_current_user, require_case_access,
                    require_min_role)
from ..db import get_db
from ..vault import audit

router = APIRouter(prefix="/cases", tags=["cases"])


class CaseCreate(BaseModel):
    title: str
    description: str = ""
    classification: str = "UNCLASSIFIED"


class CaseUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    classification: str | None = None
    status: str | None = None


class MemberAdd(BaseModel):
    username: str
    role: str = "investigator"


class NoteCreate(BaseModel):
    body: str


def _case_or_404(db, case_id):
    case = db.query(models.Case).filter(
        (models.Case.id == case_id) | (models.Case.case_id == case_id)).first()
    if not case:
        raise HTTPException(404, "Case not found")
    return case


def _serialize(case):
    return {"id": case.id, "case_id": case.case_id, "title": case.title,
            "description": case.description, "classification": case.classification,
            "status": case.status, "created_at": case.created_at.isoformat()}


@router.post("")
def create_case(payload: CaseCreate, db: Session = Depends(get_db),
                user: models.User = Depends(require_min_role("investigator"))):
    count = db.query(models.Case).count()
    case = models.Case(case_id=f"CASE-{count + 1:04d}", title=payload.title,
                       description=payload.description,
                       classification=payload.classification.upper(),
                       created_by=user.id)
    db.add(case)
    db.flush()
    db.add(models.CaseMember(case_id=case.id, user_id=user.id, role="lead"))
    audit(db, actor=user, action="CASE_CREATE", target_type="case",
          target_id=case.case_id, detail=payload.title)
    db.commit()
    return _serialize(case)


@router.get("")
def list_cases(db: Session = Depends(get_db),
               user: models.User = Depends(get_current_user)):
    if user.role == "admin":
        cases = db.query(models.Case).order_by(models.Case.created_at.desc()).all()
    else:
        member_case_ids = [m.case_id for m in
                           db.query(models.CaseMember).filter_by(user_id=user.id)]
        cases = db.query(models.Case).filter(
            (models.Case.id.in_(member_case_ids)) |
            (models.Case.created_by == user.id)).order_by(
            models.Case.created_at.desc()).all()
    return [_serialize(c) for c in cases]


@router.get("/{case_id}")
def get_case(case_id: str, db: Session = Depends(get_db),
             user: models.User = Depends(get_current_user)):
    case = _case_or_404(db, case_id)
    require_case_access(db, user, case)
    data = _serialize(case)
    data["members"] = [
        {"username": db.get(models.User, m.user_id).username, "role": m.role}
        for m in db.query(models.CaseMember).filter_by(case_id=case.id)]
    data["evidence_count"] = db.query(models.Evidence).filter_by(case_id=case.id).count()
    data["entity_count"] = db.query(models.Entity).filter_by(case_id=case.id).count()
    return data


@router.patch("/{case_id}")
def update_case(case_id: str, payload: CaseUpdate, db: Session = Depends(get_db),
                user: models.User = Depends(get_current_user)):
    case = _case_or_404(db, case_id)
    require_case_access(db, user, case)
    for field in ("title", "description", "classification", "status"):
        val = getattr(payload, field)
        if val is not None:
            setattr(case, field, val.upper() if field in ("classification", "status") else val)
    audit(db, actor=user, action="CASE_UPDATE", target_type="case",
          target_id=case.case_id, detail=str(payload.dict(exclude_none=True)))
    db.commit()
    return _serialize(case)


@router.post("/{case_id}/members")
def add_member(case_id: str, payload: MemberAdd, db: Session = Depends(get_db),
               user: models.User = Depends(get_current_user)):
    case = _case_or_404(db, case_id)
    require_case_access(db, user, case)
    member = db.query(models.User).filter_by(username=payload.username).first()
    if not member:
        raise HTTPException(404, "User not found")
    existing = db.query(models.CaseMember).filter_by(case_id=case.id,
                                                     user_id=member.id).first()
    if not existing:
        db.add(models.CaseMember(case_id=case.id, user_id=member.id, role=payload.role))
    audit(db, actor=user, action="CASE_MEMBER_ADD", target_type="case",
          target_id=case.case_id, detail=f"{payload.username} as {payload.role}")
    db.commit()
    return {"ok": True}


@router.post("/{case_id}/notes")
def add_note(case_id: str, payload: NoteCreate, db: Session = Depends(get_db),
             user: models.User = Depends(get_current_user)):
    case = _case_or_404(db, case_id)
    require_case_access(db, user, case)
    note = models.CaseNote(case_id=case.id, author_id=user.id, body=payload.body)
    db.add(note)
    audit(db, actor=user, action="CASE_NOTE", target_type="case",
          target_id=case.case_id, detail=payload.body[:200])
    db.commit()
    return {"id": note.id, "created_at": note.created_at.isoformat()}


@router.get("/{case_id}/notes")
def list_notes(case_id: str, db: Session = Depends(get_db),
               user: models.User = Depends(get_current_user)):
    case = _case_or_404(db, case_id)
    require_case_access(db, user, case)
    notes = db.query(models.CaseNote).filter_by(case_id=case.id).order_by(
        models.CaseNote.created_at.desc()).all()
    return [{"id": n.id, "body": n.body,
             "author": db.get(models.User, n.author_id).username,
             "created_at": n.created_at.isoformat()} for n in notes]
