"""Evidence pipeline: connector result -> vault -> entities -> graph -> timeline.

Every relationship carries provenance. Correlations are labeled as
correlations - never as proof.
"""

import datetime
import email.utils
import re
import uuid

from sqlalchemy.orm import Session

from . import models
from .settings import COLLECTOR_VERSION
from .vault import audit, store_evidence


def _utcnow():
    return datetime.datetime.now(datetime.timezone.utc)


def get_or_create_entity(db: Session, case: models.Case, etype: str, value: str,
                         attributes: dict = None) -> models.Entity:
    value = value.strip()
    ent = db.query(models.Entity).filter_by(case_id=case.id, type=etype,
                                            value=value).first()
    now = _utcnow()
    if ent:
        ent.last_seen = now
        if attributes:
            merged = dict(ent.attributes or {})
            merged.update(attributes)
            ent.attributes = merged
        return ent
    ent = models.Entity(
        entity_id=f"ENT-{uuid.uuid4().hex[:12].upper()}",
        case_id=case.id, type=etype, value=value,
        attributes=attributes or {},
        first_seen=now, last_seen=now,
    )
    db.add(ent)
    db.flush()
    return ent


def add_relationship(db: Session, case: models.Case, from_ent: models.Entity,
                     to_ent: models.Entity, rel_type: str,
                     evidence: models.Evidence, provenance: str = "OBSERVED",
                     detail: str = ""):
    exists = db.query(models.Relationship).filter_by(
        case_id=case.id, from_entity_id=from_ent.id, to_entity_id=to_ent.id,
        rel_type=rel_type).first()
    if exists:
        return exists
    rel = models.Relationship(
        case_id=case.id, from_entity_id=from_ent.id, to_entity_id=to_ent.id,
        rel_type=rel_type, evidence_id=evidence.id,
        provenance=provenance, detail=detail)
    db.add(rel)
    return rel


def add_timeline(db: Session, case: models.Case, timestamp, event_type: str,
                 target: str = "", source: str = "",
                 evidence: models.Evidence = None,
                 classification: str = "CURRENT", detail: str = ""):
    db.add(models.TimelineEvent(
        case_id=case.id, timestamp=timestamp, event_type=event_type,
        target=target, source=source,
        evidence_id=evidence.id if evidence else None,
        classification=classification, detail=detail))


def _mx_host(mx_entry):
    parts = str(mx_entry).split()
    return parts[1].rstrip(".") if len(parts) == 2 else str(mx_entry).rstrip(".")


def extract(db: Session, case: models.Case, evidence: models.Evidence,
            res: dict):
    """Build entities/relationships/timeline from a connector result."""
    norm = res["normalized"] or {}
    collector = res["collector"]
    collected_at = _utcnow()
    try:
        collected_at = datetime.datetime.fromisoformat(res["collected_at"])
    except (ValueError, TypeError):
        pass

    add_timeline(db, case, collected_at, f"COLLECTED:{collector}",
                 target=res["target"], source=res["source"],
                 evidence=evidence, classification="CURRENT",
                 detail=f"status={res['status']}")

    if res["status"] != "OK":
        return  # failed collections still have evidence + timeline, but no entities

    if collector == "wfip/dns":
        _extract_dns(db, case, evidence, norm)
    elif collector == "wfip/rdap":
        _extract_rdap(db, case, evidence, norm, collected_at)
    elif collector == "wfip/ip":
        _extract_ip(db, case, evidence, norm)
    elif collector == "wfip/http":
        _extract_http(db, case, evidence, norm)
    elif collector == "wfip/tls":
        _extract_tls(db, case, evidence, norm)
    elif collector == "wfip/certificates":
        _extract_certs(db, case, evidence, norm)
    elif collector == "wfip/email":
        _extract_email(db, case, evidence, norm)
    elif collector == "wfip/file":
        _extract_file(db, case, evidence, norm)


def _extract_dns(db, case, ev, norm):
    domain = get_or_create_entity(db, case, "domain", ev.target)
    for ip in norm.get("A", []) + norm.get("AAAA", []):
        if isinstance(ip, str) and not ip.startswith("{"):
            ip_ent = get_or_create_entity(db, case, "ip", ip)
            add_relationship(db, case, domain, ip_ent, "RESOLVES_TO", ev,
                             detail="observed in DNS A/AAAA answers")
    for mx in norm.get("MX", []):
        host = _mx_host(mx)
        mx_ent = get_or_create_entity(db, case, "mailserver", host)
        add_relationship(db, case, domain, mx_ent, "USES_MAILSERVER", ev,
                         detail=f"observed in MX record: {mx}")
        get_or_create_entity(db, case, "domain", host)
    for ns in norm.get("NS", []):
        if isinstance(ns, str):
            ns_ent = get_or_create_entity(db, case, "nameserver", ns.rstrip("."))
            # Shared nameserver is a correlation, not proof of common control.
            add_relationship(db, case, domain, ns_ent, "USES_NAMESERVER", ev,
                             provenance="CORRELATED",
                             detail="nameserver delegation observed; shared "
                                    "nameservers do not prove common ownership")
    for caa in norm.get("CAA", []):
        add_timeline(db, case, _utcnow(), "DNS:CAA", target=ev.target,
                     source="dns", evidence=ev, detail=str(caa)[:300])


def _extract_rdap(db, case, ev, norm, collected_at):
    target = ev.target
    ent_type = "domain" if "." in target and not target.startswith("AS") else "ip"
    if target.upper().startswith("AS"):
        ent_type = "asn"
    ent = get_or_create_entity(db, case, ent_type, target,
                               attributes={"rdap_status": norm.get("status")})
    registrar = norm.get("registrar") or {}
    handle = registrar.get("handle")
    if handle:
        org = get_or_create_entity(db, case, "organization", handle,
                                   attributes={"roles": registrar.get("roles")})
        add_relationship(db, case, ent, org, "REGISTERED_VIA", ev,
                         provenance="OBSERVED",
                         detail="registrar as reported by RDAP (registration "
                                "data, not verified identity)")
    for ns in norm.get("nameservers", []):
        name = ns.get("ldhName")
        if name:
            ns_ent = get_or_create_entity(db, case, "nameserver", name.rstrip("."))
            add_relationship(db, case, ent, ns_ent, "USES_NAMESERVER", ev,
                             provenance="CORRELATED",
                             detail="RDAP-reported delegation")
    for action, date in (norm.get("events") or {}).items():
        try:
            ts = datetime.datetime.fromisoformat(date)
        except (ValueError, TypeError):
            continue
        add_timeline(db, case, ts, f"RDAP:{action}", target=target,
                     source="rdap", evidence=ev, classification="HISTORICAL",
                     detail=f"RDAP reports {action} at {date} (registry claim)")


def _extract_ip(db, case, ev, norm):
    ip_ent = get_or_create_entity(db, case, "ip", norm["ip"])
    if norm.get("reverse_dns"):
        add_timeline(db, case, _utcnow(), "IP:REVERSE_DNS", target=norm["ip"],
                     source="dns", evidence=ev,
                     detail=f"PTR -> {norm['reverse_dns']}")
    rdap_data = norm.get("rdap") or {}
    asn = None
    for ent in (rdap_data.get("entities") or []):
        pass
    # ASN often appears in network handle or notices; also try ip-api 'as'
    geo = norm.get("geolocation") or {}
    as_field = geo.get("as", "")
    m = re.match(r"AS(\d+)", as_field or "")
    if m:
        asn = get_or_create_entity(db, case, "asn", f"AS{m.group(1)}",
                                   attributes={"name": geo.get("asname")})
        add_relationship(db, case, ip_ent, asn, "ANNOUNCED_BY", ev,
                         provenance="CORRELATED",
                         detail="ASN from geolocation/RDAP data")
    org_name = geo.get("org") or geo.get("isp")
    if org_name:
        org = get_or_create_entity(db, case, "organization", org_name)
        add_relationship(db, case, ip_ent, org, "HOSTED_ON", ev,
                         provenance="CORRELATED",
                         detail="hosting org from geolocation database "
                                "(approximate, not authoritative)")


def _extract_http(db, case, ev, norm):
    url_ent = get_or_create_entity(db, case, "url", norm["original_url"])
    chain = norm.get("redirect_chain", [])
    prev = url_ent
    for hop in chain[1:]:
        hop_ent = get_or_create_entity(db, case, "url", hop["url"])
        add_relationship(db, case, prev, hop_ent, "REDIRECTS_TO", ev,
                         detail=f"HTTP {hop['status']}")
        prev = hop_ent
    page = norm.get("page") or {}
    for linked in page.get("linked_domains", [])[:100]:
        d = get_or_create_entity(db, case, "domain", linked)
        add_relationship(db, case, url_ent, d, "LINKS_TO", ev,
                         provenance="OBSERVED",
                         detail="domain referenced in page HTML")
    for u in page.get("links", [])[:200]:
        get_or_create_entity(db, case, "url", u)


def _extract_tls(db, case, ev, norm):
    fp = norm.get("sha256_fingerprint")
    if not fp:
        return
    cert = get_or_create_entity(db, case, "certificate", fp, attributes={
        "subject": norm.get("subject"), "issuer": norm.get("issuer"),
        "not_before": norm.get("not_before"), "not_after": norm.get("not_after"),
        "serial": norm.get("serial_number")})
    host = norm.get("host")
    if host:
        d = get_or_create_entity(db, case, "domain", host)
        add_relationship(db, case, d, cert, "USES_CERTIFICATE", ev,
                         detail="certificate presented during TLS handshake")
    for san in norm.get("san", []):
        if san.startswith("DNS:"):
            sd = get_or_create_entity(db, case, "domain", san[4:])
            add_relationship(db, case, sd, cert, "USES_CERTIFICATE", ev,
                             provenance="CORRELATED",
                             detail="domain listed in certificate SAN; shared "
                                    "certificates do not prove common ownership")


def _extract_certs(db, case, ev, norm):
    domain = get_or_create_entity(db, case, "domain", ev.target)
    for c in norm.get("certificates", [])[:200]:
        cid = f"crtsh:{c.get('crtsh_id')}"
        cert = get_or_create_entity(db, case, "certificate", cid, attributes={
            "issuer": c.get("issuer"), "not_before": c.get("not_before"),
            "not_after": c.get("not_after")})
        add_relationship(db, case, domain, cert, "USES_CERTIFICATE", ev,
                         provenance="CORRELATED",
                         detail="certificate observed in CT logs (crt.sh)")
        for name in c.get("names", [])[:20]:
            name = name.lstrip("*.")
            if name and name != ev.target:
                sd = get_or_create_entity(db, case, "domain", name)
                add_relationship(db, case, sd, cert, "USES_CERTIFICATE", ev,
                                 provenance="CORRELATED",
                                 detail="co-listed in CT certificate; correlation only")


def _addr_list(vals):
    out = []
    for v in vals or []:
        for _, addr in email.utils.getaddresses([v]):
            if addr and "@" in addr:
                out.append(addr.lower())
    return out


def _extract_email(db, case, ev, norm):
    headers = norm.get("headers", {})
    from_addrs = _addr_list(headers.get("From", []))
    to_addrs = _addr_list(headers.get("To", []) + headers.get("Cc", []))
    for addr in from_addrs:
        get_or_create_entity(db, case, "email", addr)
    for addr in to_addrs:
        get_or_create_entity(db, case, "email", addr)
    for s in from_addrs:
        s_ent = get_or_create_entity(db, case, "email", s)
        for r in to_addrs:
            r_ent = get_or_create_entity(db, case, "email", r)
            # Header-declared sender/recipient: observed in the message,
            # not proof the person actually sent it.
            add_relationship(db, case, s_ent, r_ent, "SENDS_TO", ev,
                             provenance="OBSERVED",
                             detail="From/To headers as present in the message")
    for hop in norm.get("received_chain", []):
        for ip in hop.get("ips", []):
            ip_ent = get_or_create_entity(db, case, "ip", ip)
            if hop.get("by"):
                ms = get_or_create_entity(db, case, "mailserver", hop["by"])
                add_relationship(db, case, ms, ip_ent, "OBSERVED_AT", ev,
                                 detail="IP seen in Received header")
    for u in norm.get("urls", [])[:100]:
        get_or_create_entity(db, case, "url", u)
    for d in norm.get("domains", [])[:100]:
        get_or_create_entity(db, case, "domain", d)
    for a in norm.get("attachments", []):
        if a.get("sha256"):
            get_or_create_entity(db, case, "hash", a["sha256"],
                                 attributes={"filename": a.get("filename"),
                                             "size": a.get("size")})
    if norm.get("date_iso"):
        try:
            ts = datetime.datetime.fromisoformat(norm["date_iso"])
            add_timeline(db, case, ts, "EMAIL:DATE", target=ev.target,
                         source="email", evidence=ev, classification="HISTORICAL",
                         detail="Date header as present in the message "
                                "(header-declared, not independently verified)")
        except (ValueError, TypeError):
            pass


def _extract_file(db, case, ev, norm):
    f = get_or_create_entity(db, case, "file", norm.get("path") or ev.target,
                             attributes={"size": norm.get("size"),
                                         "magic": norm.get("magic_matches")})
    h = get_or_create_entity(db, case, "hash", norm["sha256"],
                             attributes={"algorithm": "SHA-256"})
    add_relationship(db, case, f, h, "HAS_HASH", ev)
    for u in (norm.get("indicators") or {}).get("urls", [])[:100]:
        u_ent = get_or_create_entity(db, case, "url", u)
        add_relationship(db, case, f, u_ent, "CONTAINS_URL", ev,
                         detail="URL string statically extracted from file")
