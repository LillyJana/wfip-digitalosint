"""Threat-intelligence connectors: key-gated, never mocked.

Without credentials each returns AUTHENTICATION_REQUIRED with setup
instructions. With credentials they query the real APIs.
"""

import json

from .base import (AUTHENTICATION_REQUIRED, COLLECTION_FAILED, NOT_FOUND, OK,
                   classify_http_error, http_get, result)
from ..settings import (ABUSEIPDB_API_KEY, SHODAN_API_KEY, URLSCAN_API_KEY,
                        VIRUSTOTAL_API_KEY)

COLLECTOR = "wfip/threatintel"


def _need_key(name, value, howto):
    if value:
        return None
    return result("threatintel", name, AUTHENTICATION_REQUIRED,
                  errors=[f"no API key configured. {howto}"],
                  normalized={"setup": howto}, collector=COLLECTOR)


def virustotal_url(url):
    missing = _need_key("virustotal", VIRUSTOTAL_API_KEY,
                        "Set VIRUSTOTAL_API_KEY env var (https://www.virustotal.com/gui/my-apikey).")
    if missing:
        return missing
    import base64
    url_id = base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")
    try:
        status, _, body = http_get(f"https://www.virustotal.com/api/v3/urls/{url_id}",
                                    headers={"x-apikey": VIRUSTOTAL_API_KEY}, timeout=20)
    except ConnectionError as exc:
        return result("threatintel", url, COLLECTION_FAILED, errors=[str(exc)],
                      collector=COLLECTOR)
    if status == 404:
        return result("threatintel", url, NOT_FOUND, raw=body,
                      errors=["URL not seen by VirusTotal"], collector=COLLECTOR)
    if status != 200:
        return result("threatintel", url, classify_http_error(status), raw=body,
                      errors=[f"VirusTotal HTTP {status}"], collector=COLLECTOR)
    data = json.loads(body.decode("utf-8", "replace"))
    attrs = data.get("data", {}).get("attributes", {})
    stats = attrs.get("last_analysis_stats", {})
    return result("threatintel", url, OK, raw=body, normalized={
        "engine_verdicts": stats,
        "reputation": attrs.get("reputation"),
        "categories": attrs.get("categories"),
        "provenance": "VirusTotal - multi-engine verdicts, not a single ground truth",
    }, collector=COLLECTOR)


def abuseipdb(ip):
    missing = _need_key("abuseipdb", ABUSEIPDB_API_KEY,
                        "Set ABUSEIPDB_API_KEY env var (https://www.abuseipdb.com/account/api).")
    if missing:
        return missing
    try:
        status, _, body = http_get("https://api.abuseipdb.com/api/v2/check",
                                    params={"ipAddress": ip, "maxAgeInDays": 90},
                                    headers={"Key": ABUSEIPDB_API_KEY,
                                             "Accept": "application/json"}, timeout=15)
    except ConnectionError as exc:
        return result("threatintel", ip, COLLECTION_FAILED, errors=[str(exc)],
                      collector=COLLECTOR)
    if status != 200:
        return result("threatintel", ip, classify_http_error(status), raw=body,
                      errors=[f"AbuseIPDB HTTP {status}"], collector=COLLECTOR)
    data = json.loads(body.decode("utf-8", "replace")).get("data", {})
    return result("threatintel", ip, OK, raw=body, normalized={
        "abuse_confidence": data.get("abuseConfidenceScore"),
        "total_reports": data.get("totalReports"),
        "last_reported": data.get("lastReportedAt"),
        "provenance": "AbuseIPDB - community reports, treat as allegation not proof",
    }, collector=COLLECTOR)


def shodan_host(ip):
    missing = _need_key("shodan", SHODAN_API_KEY,
                        "Set SHODAN_API_KEY env var (https://account.shodan.io/).")
    if missing:
        return missing
    try:
        status, _, body = http_get(f"https://api.shodan.io/shodan/host/{ip}",
                                    params={"key": SHODAN_API_KEY}, timeout=20)
    except ConnectionError as exc:
        return result("threatintel", ip, COLLECTION_FAILED, errors=[str(exc)],
                      collector=COLLECTOR)
    if status == 404:
        return result("threatintel", ip, NOT_FOUND, raw=body,
                      errors=["no Shodan data for host"], collector=COLLECTOR)
    if status != 200:
        return result("threatintel", ip, classify_http_error(status), raw=body,
                      errors=[f"Shodan HTTP {status}"], collector=COLLECTOR)
    data = json.loads(body.decode("utf-8", "replace"))
    return result("threatintel", ip, OK, raw=body, normalized={
        "org": data.get("org"), "os": data.get("os"),
        "ports": data.get("ports"), "hostnames": data.get("hostnames"),
        "vulns": list((data.get("vulns") or {}).keys()),
        "last_update": data.get("last_update"),
        "provenance": "Shodan - internet scan observations",
    }, collector=COLLECTOR)
