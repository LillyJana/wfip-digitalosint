"""Email forensics connector: parse .eml / raw RFC 5322 messages.

Extracts headers, Received-chain chronology, authentication results
(SPF/DKIM/DMARC as *reported* by the receiving server), URLs, domains,
IPs, mail servers and attachments. The original message bytes are
preserved verbatim as the raw artifact. No claim is made about the
true sender beyond what the headers literally contain.
"""

import email
import email.policy
import email.utils
import hashlib
import ipaddress
import json
import re
import urllib.parse

from .base import (COLLECTION_FAILED, OK, result, sha256_bytes, utcnow_iso)

COLLECTOR = "wfip/email"

URL_RE = re.compile(r"https?://[^\s'\"<>\\]+", re.I)
IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
RECEIVED_IP = re.compile(r"\[(\d{1,3}(?:\.\d{1,3}){3})\]")
RECEIVED_FROM = re.compile(r"from\s+([^\s;()]+)", re.I)
RECEIVED_BY = re.compile(r"\bby\s+([^\s;()]+)", re.I)
RECEIVED_DATE = re.compile(r";\s*(.+)$")


def _parse_received(headers):
    """Return the Received chain oldest-first with extracted hops."""
    chain = []
    for raw in headers:
        hop = {"raw": raw[:1000]}
        m = RECEIVED_FROM.search(raw)
        hop["from"] = m.group(1) if m else None
        m = RECEIVED_BY.search(raw)
        hop["by"] = m.group(1) if m else None
        ips = RECEIVED_IP.findall(raw)
        hop["ips"] = ips
        m = RECEIVED_DATE.search(raw.replace("\r\n", " ").replace("\n", " "))
        if m:
            try:
                dt = email.utils.parsedate_to_datetime(m.group(1).strip())
                hop["date"] = dt.isoformat()
            except (ValueError, TypeError):
                hop["date"] = None
        chain.append(hop)
    chain.reverse()  # Received headers are newest-first; present oldest-first
    return chain


def _auth_results(headers):
    out = []
    for raw in headers:
        entry = {"raw": raw[:1000], "spf": None, "dkim": None, "dmarc": None}
        for mech in ("spf", "dkim", "dmarc"):
            m = re.search(rf"{mech}=(\w+)", raw, re.I)
            if m:
                entry[mech] = m.group(1).lower()
        out.append(entry)
    return out


def _walk_parts(msg):
    parts, attachments = [], []
    for part in msg.walk():
        ctype = part.get_content_type()
        disp = part.get_content_disposition()
        filename = part.get_filename()
        payload = part.get_payload(decode=True) or b""
        info = {"content_type": ctype, "disposition": disp,
                "filename": filename, "size": len(payload),
                "sha256": sha256_bytes(payload) if payload else None}
        parts.append(info)
        if disp == "attachment" or filename:
            attachments.append(info)
    return parts, attachments


def parse(raw: bytes):
    try:
        msg = email.message_from_bytes(raw, policy=email.policy.default)
    except Exception as exc:  # noqa: BLE001
        return result("email", "message", COLLECTION_FAILED,
                      errors=[f"parse failed: {exc}"], collector=COLLECTOR)

    headers = {}
    for key in ("From", "To", "Cc", "Bcc", "Reply-To", "Return-Path",
                "Message-ID", "Date", "Subject", "X-Originating-IP",
                "Authentication-Results", "DKIM-Signature"):
        vals = msg.get_all(key)
        if vals:
            headers[key] = [str(v) for v in vals]

    received = _parse_received(msg.get_all("Received", []))
    authr = _auth_results(msg.get_all("Authentication-Results", []))

    bodies = []
    for part in msg.walk():
        if part.get_content_type().startswith("text/") and not part.get_filename():
            try:
                bodies.append(part.get_content())
            except Exception:  # noqa: BLE001
                pass
    text = "\n".join(b for b in bodies if isinstance(b, str))

    urls = sorted(set(URL_RE.findall(text)))
    domains = sorted({urllib.parse.urlparse(u).hostname for u in urls
                      if urllib.parse.urlparse(u).hostname})
    ips = sorted(set(IP_RE.findall(text)))
    mail_servers = sorted({h.get("by") for h in received if h.get("by")})

    parts, attachments = _walk_parts(msg)

    try:
        date_iso = email.utils.parsedate_to_datetime(str(msg.get("Date"))).isoformat()
    except (ValueError, TypeError):
        date_iso = None

    normalized = {
        "headers": headers,
        "date_iso": date_iso,
        "received_chain": received,
        "authentication_results": authr,
        "auth_summary": {
            "note": "SPF/DKIM/DMARC values are *as reported* by the receiving "
                    "server in Authentication-Results; they describe the "
                    "envelope as received, not proven authorship.",
            "observed": authr,
        },
        "mime_parts": len(parts),
        "attachments": attachments,
        "urls": urls[:200],
        "domains": domains[:200],
        "ips_in_body": ips[:200],
        "mail_servers": mail_servers,
        "body_chars": len(text),
    }
    return result("email", str(msg.get("Subject", "(no subject)"))[:200],
                  OK, raw=raw, normalized=normalized, collector=COLLECTOR)


def collect_file(path):
    try:
        with open(path, "rb") as fh:
            raw = fh.read()
    except OSError as exc:
        return result("email", path, COLLECTION_FAILED, errors=[str(exc)],
                      collector=COLLECTOR)
    res = parse(raw)
    res["target"] = path
    return res
