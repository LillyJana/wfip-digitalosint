"""TLS/certificate connector: live handshake capture.

Extracts subject, issuer, SANs, validity, serial, public-key info and
SHA-256 fingerprint from the presented certificate. A shared
certificate is recorded as an OBSERVED correlation - never as proof
of common ownership.
"""

import hashlib
import json
import socket
import ssl
import urllib.parse

from .base import (COLLECTION_FAILED, NOT_FOUND, OK, result, sha256_bytes)

COLLECTOR = "wfip/tls"


def _name_tuple(nt):
    return ", ".join(f"{k}={v}" for seq in nt for k, v in seq)


def collect(host, port=443, timeout=15):
    host = host.strip()
    if "://" in host:
        host = urllib.parse.urlparse(host).hostname or host
    host = host.rstrip(".")
    ctx = ssl.create_default_context()
    raw_cert = b""
    normalized, errors = {}, []
    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                der = ssock.getpeercert(binary_form=True)
                cipher = ssock.cipher()
                version = ssock.version()
                raw_cert = der or b""
                pem_cert = ssl.DER_cert_to_PEM_cert(der) if der else ""
                cert_dict = ssock.getpeercert() or {}
    except ssl.SSLError as exc:
        return result("tls", f"{host}:{port}", COLLECTION_FAILED,
                      errors=[f"TLS handshake failed: {exc}"], collector=COLLECTOR)
    except (socket.timeout, OSError) as exc:
        return result("tls", f"{host}:{port}", COLLECTION_FAILED,
                      errors=[f"connection failed: {exc}"], collector=COLLECTOR)

    if not raw_cert:
        return result("tls", f"{host}:{port}", NOT_FOUND,
                      errors=["no certificate presented"], collector=COLLECTOR)

    fingerprint = hashlib.sha256(raw_cert).hexdigest()
    sans = []
    for typ, val in cert_dict.get("subjectAltName", []):
        sans.append(f"{typ}:{val}")
    normalized = {
        "host": host, "port": port,
        "tls_version": version, "cipher": cipher[0] if cipher else None,
        "subject": _name_tuple(cert_dict.get("subject", ())),
        "issuer": _name_tuple(cert_dict.get("issuer", ())),
        "serial_number": cert_dict.get("serialNumber"),
        "not_before": cert_dict.get("notBefore"),
        "not_after": cert_dict.get("notAfter"),
        "san": sans,
        "sha256_fingerprint": fingerprint,
        "pem_truncated": pem_cert[:2000],
        "chain_note": "Only the leaf certificate is captured by this collector; "
                      "full chain retrieval requires an explicit chain-building pass.",
    }
    raw = json.dumps({"host": host, "fingerprint": fingerprint,
                      "cert": cert_dict}, indent=2, default=str).encode()
    return result("tls", f"{host}:{port}", OK, raw=raw,
                  normalized=normalized, collector=COLLECTOR)
