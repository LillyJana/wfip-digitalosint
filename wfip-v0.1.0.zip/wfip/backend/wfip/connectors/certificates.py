"""Certificate-transparency connector (crt.sh): public cert observations."""

import json

from .base import (COLLECTION_FAILED, NOT_FOUND, OK, classify_http_error,
                   http_get, result)

COLLECTOR = "wfip/certificates"


def collect(domain):
    domain = domain.strip().lower().rstrip(".")
    try:
        status, _, body = http_get("https://crt.sh/",
                                   params={"q": f"%.{domain}", "output": "json"},
                                   timeout=30)
    except ConnectionError as exc:
        return result("certificates", domain, COLLECTION_FAILED,
                      errors=[str(exc)], collector=COLLECTOR)
    if status != 200:
        return result("certificates", domain, classify_http_error(status),
                      raw=body, errors=[f"crt.sh HTTP {status}"],
                      collector=COLLECTOR)
    try:
        entries = json.loads(body.decode("utf-8", "replace"))
    except ValueError as exc:
        return result("certificates", domain, COLLECTION_FAILED, raw=body,
                      errors=[f"crt.sh invalid JSON: {exc}"], collector=COLLECTOR)
    certs = []
    for e in entries:
        names = [n.strip() for n in e.get("name_value", "").splitlines() if n.strip()]
        certs.append({
            "crtsh_id": e.get("id"),
            "issuer": (e.get("issuer_name") or "")[:200],
            "names": names,
            "not_before": e.get("not_before"),
            "not_after": e.get("not_after"),
        })
    normalized = {"domain": domain, "certificate_count": len(certs),
                  "certificates": certs[:200]}
    if len(certs) > 200:
        normalized["truncated"] = True
    status = OK if certs else NOT_FOUND
    errors = [] if certs else ["no certificates observed in CT logs for this domain"]
    return result("certificates", domain, status, raw=body,
                  normalized=normalized, errors=errors, collector=COLLECTOR)
