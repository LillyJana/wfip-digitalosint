"""DNS connector: direct UDP + DNS-over-HTTPS fallback.

Covers A, AAAA, MX, NS, TXT, SOA, CAA, plus DNSSEC and email-auth
(SPF/DKIM/DMARC) derivation from TXT records.
"""

import json
import random
import socket
import struct

from .base import (COLLECTION_FAILED, NOT_FOUND, OK, classify_http_error,
                   http_get, result, utcnow_iso)

QTYPE = {"A": 1, "AAAA": 28, "CNAME": 5, "MX": 15, "NS": 2, "TXT": 16,
         "SOA": 6, "CAA": 257, "DS": 43, "DNSKEY": 48}
DNS_SERVERS = ["1.1.1.1", "8.8.8.8", "9.9.9.9"]
COLLECTOR = "wfip/dns"


def _encode(name):
    out = b""
    for part in name.rstrip(".").split("."):
        e = part.encode("idna")
        out += bytes([len(e)]) + e
    return out + b"\x00"


def _decode(data, off):
    labels, jumped, orig = [], False, off
    while True:
        ln = data[off]
        if ln == 0:
            off += 1
            break
        if ln & 0xC0 == 0xC0:
            ptr = struct.unpack(">H", data[off:off + 2])[0] & 0x3FFF
            if not jumped:
                orig = off + 2
            off, jumped = ptr, True
            continue
        off += 1
        labels.append(data[off:off + ln].decode("utf-8", "replace"))
        off += ln
    return ".".join(labels), (orig if jumped else off)


def _rdata(rtype, rdata, data, roff):
    try:
        if rtype in (2, 5):
            n, _ = _decode(data, roff)
            return n
        if rtype == 1:
            return socket.inet_ntoa(rdata)
        if rtype == 28:
            return socket.inet_ntop(socket.AF_INET6, rdata)
        if rtype == 15:
            pref = struct.unpack(">H", rdata[:2])[0]
            host, _ = _decode(data, roff + 2)
            return f"{pref} {host}"
        if rtype == 16:
            out, i = [], 0
            while i < len(rdata):
                ln = rdata[i]
                out.append(rdata[i + 1:i + 1 + ln].decode("utf-8", "replace"))
                i += 1 + ln
            return "".join(out)
        if rtype == 6:
            m, o = _decode(data, roff)
            r, o = _decode(data, o)
            serial = struct.unpack(">I", data[o:o + 4])[0]
            return {"mname": m, "rname": r, "serial": serial}
        if rtype == 257:
            tag = rdata[2:2 + rdata[1]].decode()
            return f"flag={rdata[0]} {tag} {rdata[2 + rdata[1]:].decode('utf-8', 'replace')}"
        if rtype == 48:  # DNSKEY
            flags = struct.unpack(">H", rdata[:2])[0]
            return {"flags": flags, "key_tag": _key_tag(rdata),
                    "sep": bool(flags & 1), "algorithm": rdata[3]}
        if rtype == 43:  # DS
            return {"key_tag": struct.unpack(">H", rdata[:2])[0],
                    "algorithm": rdata[2], "digest_type": rdata[3],
                    "digest": rdata[4:].hex()}
    except Exception:  # noqa: BLE001 - best effort
        pass
    return rdata.hex()


def _key_tag(rdata):
    """RFC 4034 Appendix B key-tag calculation."""
    tag = 0
    for i in range(len(rdata)):
        tag += rdata[i] << 8 if i % 2 == 0 else rdata[i]
    tag += (tag >> 16) & 0xFFFF
    return tag & 0xFFFF


def _query_udp(name, qtype, timeout=5):
    qid = random.randint(0, 65535)
    pkt = (struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 0)
           + _encode(name) + struct.pack(">HH", QTYPE[qtype], 1))
    for server in DNS_SERVERS:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        try:
            s.sendto(pkt, (server, 53))
            data, _ = s.recvfrom(4096)
        except (socket.timeout, OSError):
            continue
        finally:
            s.close()
        if len(data) < 12 or struct.unpack(">H", data[:2])[0] != qid:
            continue
        answers = _parse_response(data, len(pkt))
        if answers:
            return answers, f"udp:{server}"
    return [], None


def _parse_response(data, qlen):
    ancount = struct.unpack(">H", data[6:8])[0]
    off, answers = qlen, []
    try:
        for _ in range(ancount):
            _, off = _decode(data, off)
            rtype, _, _, rdlen = struct.unpack(">HHIH", data[off:off + 10])
            roff = off + 10
            answers.append(_rdata(rtype, data[roff:roff + rdlen], data, roff))
            off = roff + rdlen
    except (struct.error, IndexError):
        pass
    return answers


def _query_doh(name, qtype, timeout=10):
    try:
        status, _, body = http_get(
            "https://cloudflare-dns.com/dns-query",
            params={"name": name, "type": qtype},
            headers={"Accept": "application/dns-json"}, timeout=timeout)
    except ConnectionError as exc:
        return [], str(exc)
    if status != 200:
        return [], f"doh http {status}"
    try:
        data = json.loads(body.decode("utf-8", "replace"))
    except ValueError:
        return [], "doh invalid json"
    out = []
    for a in data.get("Answer", []):
        atype, text = a.get("type"), a.get("data", "")
        if atype == 16:
            text = text.strip('"')
        if atype == 15:
            text = text  # "pref host"
        out.append(text)
    dnssec = data.get("AD") is True
    return out, f"doh:cloudflare (AD={dnssec})"


def query(name, qtype="A"):
    answers, via = _query_udp(name, qtype)
    if not answers:
        answers, via = _query_doh(name, qtype)
    return answers, via


def derive_email_auth(txt_records):
    """SPF / DMARC from TXT; DKIM needs selector brute-force (not done silently)."""
    spf = [t for t in txt_records if isinstance(t, str) and t.startswith("v=spf1")]
    dmarc = [t for t in txt_records if isinstance(t, str) and t.startswith("v=DMARC1")]
    return {"spf": spf, "dmarc": dmarc,
            "dkim": "not probed - DKIM discovery requires selector enumeration; "
                    "use authorized selector lists"}


def collect(domain):
    domain = domain.strip().lower().rstrip(".")
    normalized, raws, errors = {}, [], []
    via = None
    for qt in ["A", "AAAA", "MX", "NS", "TXT", "SOA", "CAA", "DNSKEY", "DS"]:
        answers, v = query(domain, qt)
        if v and not via:
            via = v
        normalized[qt] = answers
    email_auth = derive_email_auth(normalized.get("TXT", []))
    normalized["email_auth"] = email_auth
    normalized["dnssec"] = {
        "dnskey_present": bool(normalized.get("DNSKEY")),
        "ds_present": bool(normalized.get("DS")),
        "note": "Presence of DNSKEY/DS records observed; full chain validation "
                "requires a validating resolver.",
    }
    raws.append(json.dumps({"domain": domain, "via": via,
                            "records": {k: v for k, v in normalized.items()
                                        if k not in ("email_auth", "dnssec")}},
                           indent=2).encode())
    status = OK if any(normalized.get(q) for q in ("A", "AAAA", "MX", "NS")) else NOT_FOUND
    if status == NOT_FOUND:
        errors.append("no A/AAAA/MX/NS records observed for this domain")
    return result("dns", domain, status,
                  raw=b"\n".join(raws), normalized=normalized,
                  errors=errors, collector=COLLECTOR)


def reverse(ip):
    try:
        name = socket.gethostbyaddr(ip)[0]
        return result("dns", ip, OK, raw=name.encode(),
                      normalized={"ptr": name}, collector=COLLECTOR)
    except (socket.herror, socket.gaierror, OSError) as exc:
        return result("dns", ip, NOT_FOUND, errors=[f"no PTR record: {exc}"],
                      normalized={"ptr": None}, collector=COLLECTOR)
