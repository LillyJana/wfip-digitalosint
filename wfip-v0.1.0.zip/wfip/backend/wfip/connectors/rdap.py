"""RDAP connector: registration data via the IANA RDAP bootstrap."""

import json
import urllib.parse

from .base import (ACCESS_RESTRICTED, AUTHENTICATION_REQUIRED,
                   COLLECTION_FAILED, NOT_FOUND, OK, classify_http_error,
                   http_get, http_get_with_curl_fallback, result)

COLLECTOR = "wfip/rdap"
RDAP_DNS_BOOTSTRAP = "https://data.iana.org/rdap/dns.json"
RDAP_IPV4_BOOTSTRAP = "https://data.iana.org/rdap/ipv4.json"
RDAP_IPV6_BOOTSTRAP = "https://data.iana.org/rdap/ipv6.json"
RDAP_ASN_BOOTSTRAP = "https://data.iana.org/rdap/asn.json"


def _bootstrap(base, key, suffix_match=False):
    """Find the authoritative RDAP server for key using IANA bootstrap.

    DNS bootstraps match on TLD suffix; IP/ASN bootstraps match on prefix.
    """
    status, _, body = http_get(base)
    if status != 200:
        raise ConnectionError(f"IANA bootstrap unavailable (HTTP {status})")
    data = json.loads(body.decode("utf-8", "replace"))
    best, best_len = None, -1
    for svc in data.get("services", []):
        prefixes, urls = svc[0], svc[1]
        for prefix in prefixes:
            if suffix_match:
                hit = key == prefix or key.endswith("." + prefix)
            else:
                hit = key.startswith(prefix)
            if hit and len(prefix) > best_len:
                best, best_len = urls[0], len(prefix)
    if not best:
        raise LookupError("no RDAP server covers this key")
    return best.rstrip("/")


def _summarize(rdap):
    """Normalized view: never invent fields that are absent."""
    def _entities(role=None):
        out = []
        for ent in rdap.get("entities", []):
            roles = ent.get("roles", [])
            if role and role not in roles:
                continue
            handle = ent.get("handle")
            vcard = {}
            for item in ent.get("vcardArray", [None, []])[1] or []:
                if isinstance(item, list) and len(item) >= 4:
                    vcard[item[0]] = item[3]
            out.append({"handle": handle, "roles": roles, "vcard": vcard})
        return out

    events = {e.get("eventAction"): e.get("eventDate")
              for e in rdap.get("events", []) if e.get("eventAction")}
    nameservers = []
    for ns in rdap.get("nameservers", []):
        nameservers.append({"ldhName": ns.get("ldhName"),
                            "ips": [a.get("v4") or a.get("v6")
                                    for a in ns.get("ipAddresses", {}).values()
                                    for a in ([a] if isinstance(a, str) else a)]})
    return {
        "objectClassName": rdap.get("objectClassName"),
        "handle": rdap.get("handle"),
        "ldhName": rdap.get("ldhName"),
        "unicodeName": rdap.get("unicodeName"),
        "status": rdap.get("status"),
        "events": events,
        "entities": _entities(),
        "registrar": next((e for e in _entities("registrar")), None),
        "nameservers": nameservers,
        "notices": [{"title": n.get("title"), "description": n.get("description")}
                    for n in rdap.get("notices", [])],
    }


def _fetch(url):
    try:
        status, _, body = http_get_with_curl_fallback(
            url, headers={"Accept": "application/rdap+json"})
    except ConnectionError as exc:
        return result("rdap", url, COLLECTION_FAILED, errors=[str(exc)],
                      collector=COLLECTOR)
    if status == 404:
        return result("rdap", url, NOT_FOUND, raw=body,
                      errors=["object not found in RDAP"], collector=COLLECTOR)
    if status in (401, 403):
        return result("rdap", url, ACCESS_RESTRICTED, raw=body,
                      errors=[f"RDAP server refused (HTTP {status})"],
                      collector=COLLECTOR)
    if status != 200:
        return result("rdap", url, classify_http_error(status), raw=body,
                      errors=[f"RDAP HTTP {status}"], collector=COLLECTOR)
    try:
        data = json.loads(body.decode("utf-8", "replace"))
    except ValueError as exc:
        return result("rdap", url, COLLECTION_FAILED, raw=body,
                      errors=[f"invalid RDAP JSON: {exc}"], collector=COLLECTOR)
    return result("rdap", url, OK, raw=body, normalized=_summarize(data),
                  collector=COLLECTOR)


def collect_domain(domain):
    domain = domain.strip().lower().rstrip(".")
    try:
        base = _bootstrap(RDAP_DNS_BOOTSTRAP, domain, suffix_match=True)
    except (ConnectionError, LookupError) as exc:
        return result("rdap", domain, COLLECTION_FAILED, errors=[str(exc)],
                      collector=COLLECTOR)
    res = _fetch(f"{base}/domain/{urllib.parse.quote(domain)}")
    res["target"] = domain
    return res


def collect_ip(ip):
    ip = ip.strip()
    try:
        base = _bootstrap(RDAP_IPV4_BOOTSTRAP if "." in ip else RDAP_IPV6_BOOTSTRAP, ip)
    except (ConnectionError, LookupError) as exc:
        return result("rdap", ip, COLLECTION_FAILED, errors=[str(exc)],
                      collector=COLLECTOR)
    res = _fetch(f"{base}/ip/{urllib.parse.quote(ip)}")
    res["target"] = ip
    norm = res["normalized"]
    if norm:
        norm["network"] = {"name": norm.get("handle"), "cidr": norm.get("ldhName")}
    return res


def collect_asn(asn):
    asn = str(asn).strip().upper().lstrip("AS")
    try:
        base = _bootstrap(RDAP_ASN_BOOTSTRAP, asn)
    except (ConnectionError, LookupError) as exc:
        return result("rdap", f"AS{asn}", COLLECTION_FAILED, errors=[str(exc)],
                      collector=COLLECTOR)
    res = _fetch(f"{base}/autnum/{asn}")
    res["target"] = f"AS{asn}"
    return res
