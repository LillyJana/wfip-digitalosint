"""IP intelligence connector: geolocation, RDAP network data, reverse DNS.

Facts are labeled by origin; third-party database content is marked as
such and never presented as guaranteed truth.
"""

import ipaddress
import json
import socket

from . import rdap
from .base import (COLLECTION_FAILED, NOT_FOUND, OK, classify_http_error,
                   http_get, result)
from .dns import reverse as reverse_dns

COLLECTOR = "wfip/ip"


def collect(target):
    target = target.strip()
    try:
        parsed = ipaddress.ip_address(target)
    except ValueError:
        try:
            resolved = socket.gethostbyname(target)
        except socket.gaierror as exc:
            return result("ip", target, NOT_FOUND,
                          errors=[f"cannot resolve hostname: {exc}"],
                          collector=COLLECTOR)
        parsed = ipaddress.ip_address(resolved)
        target = resolved

    normalized = {
        "ip": str(parsed),
        "version": parsed.version,
        "is_private": parsed.is_private,
        "is_global": parsed.is_global,
        "reverse_dns": None, "geolocation": None, "rdap": None,
    }
    errors = []
    rev = reverse_dns(str(parsed))
    if rev["status"] == OK:
        normalized["reverse_dns"] = rev["normalized"]["ptr"]

    if parsed.is_private:
        normalized["note"] = ("private address - external intelligence "
                              "sources skipped")
        return result("ip", str(parsed), OK, raw=json.dumps(normalized).encode(),
                      normalized=normalized, collector=COLLECTOR)

    # Geolocation (free, no key)
    try:
        status, _, body = http_get(
            f"http://ip-api.com/json/{parsed}",
            params={"fields": "status,message,country,countryCode,regionName,city,"
                              "zip,lat,lon,timezone,isp,org,as,asname,query"},
            timeout=15)
        if status == 200:
            data = json.loads(body.decode("utf-8", "replace"))
            if data.get("status") == "success":
                data.pop("status", None)
                data["provenance"] = ("third-party geolocation database "
                                      "(ip-api.com) - approximate, not authoritative")
                normalized["geolocation"] = data
            else:
                errors.append(f"geolocation: {data.get('message')}")
        else:
            errors.append(f"geolocation HTTP {status}")
    except (ConnectionError, ValueError) as exc:
        errors.append(f"geolocation failed: {exc}")

    # RDAP network/ASN data (authoritative registries)
    rdap_res = rdap.collect_ip(str(parsed))
    if rdap_res["status"] == OK:
        normalized["rdap"] = rdap_res["normalized"]
    else:
        errors.append(f"rdap: {rdap_res['status']} - {rdap_res['errors']}")

    raw = json.dumps({"ip": str(parsed), "geolocation": normalized["geolocation"],
                      "rdap": normalized["rdap"]}, indent=2, default=str).encode()
    return result("ip", str(parsed), OK, raw=raw, normalized=normalized,
                  errors=errors, collector=COLLECTOR)
