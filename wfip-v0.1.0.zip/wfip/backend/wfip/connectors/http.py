"""HTTP/website forensics connector.

Collects redirect chain, headers, body (bounded), robots.txt, sitemap,
linked assets and domains. NEVER executes JavaScript or plugins -
pure static collection of publicly served bytes.
"""

import hashlib
import json
import re
import urllib.error
import urllib.parse

from .base import (ACCESS_RESTRICTED, COLLECTION_FAILED, NOT_FOUND, OK,
                   classify_http_error, http_get, result, sha256_bytes)
from ..settings import MAX_HTTP_BODY

COLLECTOR = "wfip/http"
LINK_RE = re.compile(r'''(?:href|src|action|data-src)\s*=\s*["']([^"'#]+)["']''', re.I)
SCRIPT_RE = re.compile(r'''<script[^>]+src\s*=\s*["']([^"']+)["']''', re.I)
META_RE = re.compile(r'''<meta[^>]+(?:name|property)\s*=\s*["']([^"']+)["'][^>]+content\s*=\s*["']([^"']*)["']''', re.I)
TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.I | re.S)


def _fetch(url, timeout=25):
    import urllib.request
    req_headers = {"User-Agent": "WFIP/wfip-collectors/0.1.0 (authorized investigative collection)"}
    # Manual redirect handling so the full chain is recorded.
    chain, current, seen = [], url, set()
    for _ in range(10):
        if current in seen:
            return chain, None, "redirect loop detected"
        seen.add(current)
        req = urllib.request.Request(current, headers=req_headers)
        try:
            resp = urllib.request.urlopen(req, timeout=timeout)
            status, headers, body = resp.status, dict(resp.headers), resp.read(MAX_HTTP_BODY + 1)
            final = resp.url
            resp.close()
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read(MAX_HTTP_BODY + 1)
            except Exception:
                body = b""
            status, headers, final = exc.code, dict(exc.headers or {}), exc.url or current
        except Exception as exc:  # noqa: BLE001
            return chain, None, f"fetch failed: {exc}"
        location = headers.get("Location")
        chain.append({"url": current, "status": status,
                      "server": headers.get("Server"),
                      "content_type": headers.get("Content-Type"),
                      "content_length": headers.get("Content-Length"),
                      "location": location})
        if status in (301, 302, 303, 307, 308) and location:
            current = urllib.parse.urljoin(current, location)
            continue
        return chain, {"status": status, "headers": headers, "body": body,
                       "final_url": final}, None
    return chain, None, "too many redirects"


def _extract_links(base, html):
    links, scripts, metas = set(), set(), {}
    for m in LINK_RE.finditer(html):
        links.add(urllib.parse.urljoin(base, m.group(1).strip()))
    for m in SCRIPT_RE.finditer(html):
        scripts.add(urllib.parse.urljoin(base, m.group(1).strip()))
    for m in META_RE.finditer(html):
        metas[m.group(1).strip().lower()] = m.group(2).strip()[:500]
    title = TITLE_RE.search(html)
    domains = set()
    for link in links | scripts:
        host = urllib.parse.urlparse(link).hostname
        if host:
            domains.add(host.lower())
    return {
        "title": title.group(1).strip()[:300] if title else None,
        "meta": metas,
        "links": sorted(links)[:500],
        "scripts": sorted(scripts)[:200],
        "linked_domains": sorted(domains),
    }


def _public_file(base, name):
    url = urllib.parse.urljoin(base, "/" + name)
    try:
        status, _, body = http_get(url, timeout=15)
    except ConnectionError:
        return {"present": False, "reason": "fetch failed"}
    if status == 200:
        text = body[:20000].decode("utf-8", "replace")
        return {"present": True, "url": url, "sha256": sha256_bytes(body),
                "preview": text[:2000]}
    return {"present": False, "reason": f"HTTP {status}"}


def collect(url):
    url = url.strip()
    if "://" not in url:
        url = "https://" + url
    chain, final, fetch_error = _fetch(url)
    errors = []
    if fetch_error:
        errors.append(fetch_error)
    if not chain:
        return result("http", url, COLLECTION_FAILED, errors=errors or ["no response"],
                      normalized={"redirect_chain": []}, collector=COLLECTOR)

    last = chain[-1]
    status = last["status"]
    normalized = {
        "original_url": url,
        "final_url": final["final_url"] if final else None,
        "redirect_chain": chain,
        "http_status": status,
        "headers": final["headers"] if final else {},
    }
    raw_parts = [json.dumps({"chain": chain}, indent=2).encode()]
    body = final["body"] if final else b""
    truncated = len(body) > MAX_HTTP_BODY
    body = body[:MAX_HTTP_BODY]
    normalized["body_sha256"] = sha256_bytes(body)
    normalized["body_bytes"] = len(body)
    normalized["body_truncated"] = truncated
    raw_parts.append(body)

    ctype = (final["headers"].get("Content-Type", "") if final else "")
    if "html" in ctype and body:
        html = body.decode("utf-8", "replace")
        extracted = _extract_links(normalized["final_url"] or url, html)
        normalized["page"] = extracted
    else:
        normalized["page"] = {"note": f"non-HTML content ({ctype or 'unknown'}) - "
                                      "link extraction skipped"}

    base = "{0.scheme}://{0.netloc}".format(urllib.parse.urlparse(normalized["final_url"] or url))
    normalized["robots_txt"] = _public_file(base, "robots.txt")
    normalized["sitemap_xml"] = _public_file(base, "sitemap.xml")

    if status == 404:
        coll_status, errors = NOT_FOUND, errors + ["HTTP 404"]
    elif status in (401, 403):
        coll_status, errors = ACCESS_RESTRICTED, errors + [f"HTTP {status}"]
    elif status >= 400:
        coll_status, errors = COLLECTION_FAILED, errors + [f"HTTP {status}"]
    else:
        coll_status = OK
    return result("http", url, coll_status, raw=b"\n-----BODY-----\n".join(raw_parts),
                  normalized=normalized, errors=errors, collector=COLLECTOR)
