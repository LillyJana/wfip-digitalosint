"""File forensics connector: hashing, identification, metadata, IOCs.

Potentially malicious files are NEVER executed - only static analysis.
"""

import hashlib
import json
import math
import os
import re
import struct
import zipfile

from .base import (COLLECTION_FAILED, OK, result, sha256_bytes)

COLLECTOR = "wfip/file"

SIGNATURES = [
    (b"\xFF\xD8\xFF", "JPEG image"), (b"\x89PNG\r\n\x1a\n", "PNG image"),
    (b"GIF87a", "GIF image"), (b"GIF89a", "GIF image"), (b"%PDF-", "PDF document"),
    (b"PK\x03\x04", "ZIP archive"), (b"\x1f\x8b\x08", "GZIP archive"),
    (b"BZh", "BZIP2 archive"), (b"\x37\x7A\xBC\xAF\x27\x1C", "7-Zip archive"),
    (b"MZ", "Windows executable (PE)"), (b"\x7fELF", "ELF executable"),
    (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "OLE compound document"),
    (b"SQLite format 3\x00", "SQLite database"), (b"BM", "BMP image"),
    (b"II*\x00", "TIFF image"), (b"MM\x00*", "TIFF image"),
    (b"fLaC", "FLAC audio"), (b"OggS", "OGG container"), (b"ID3", "MP3 audio"),
    (b"%!PS", "PostScript"), (b"-----BEGIN", "PEM data"),
]
URL_RE = re.compile(rb"https?://[^\s'\"<>\\]{4,}")
EMAIL_RE = re.compile(rb"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
IP_RE = re.compile(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b")


def _hashes(path):
    hs = {a: hashlib.new(a) for a in ("md5", "sha1", "sha256")}
    size = 0
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            size += len(chunk)
            for h in hs.values():
                h.update(chunk)
    return {a: h.hexdigest() for a, h in hs.items()}, size


def _entropy(path):
    counts, total = [0] * 256, 0
    with open(path, "rb") as fh:
        data = fh.read(65536)
    for b in data:
        counts[b] += 1
        total += 1
    if not total:
        return 0.0
    return round(-sum((c / total) * math.log2(c / total) for c in counts if c), 3)


def _zip_info(path):
    try:
        with zipfile.ZipFile(path) as zf:
            return {"entries": [i.filename for i in zf.infolist()][:200],
                    "count": len(zf.infolist())}
    except zipfile.BadZipFile:
        return {"error": "not a valid zip"}


def _iocs(path):
    with open(path, "rb") as fh:
        data = fh.read(10 * 1024 * 1024)  # bounded scan
    urls = sorted({m.decode() for m in URL_RE.findall(data)})[:200]
    emails = sorted({m.decode() for m in EMAIL_RE.findall(data)})[:200]
    ips = sorted({m.decode() for m in IP_RE.findall(data)})[:200]
    return {"urls": urls, "emails": emails, "ips": ips}


def collect(path):
    if not os.path.isfile(path):
        return result("file", path, COLLECTION_FAILED,
                      errors=["not a file"], collector=COLLECTOR)
    try:
        digests, size = _hashes(path)
        with open(path, "rb") as fh:
            head = fh.read(64)
    except OSError as exc:
        return result("file", path, COLLECTION_FAILED, errors=[str(exc)],
                      collector=COLLECTOR)

    matches = [label for sig, label in SIGNATURES if head.startswith(sig)]
    st = os.stat(path)
    normalized = {
        "path": path, "size": size,
        "sha256": digests["sha256"], "sha1": digests["sha1"],
        "md5": digests["md5"],
        "md5_note": "MD5 retained for legacy identification only - not for integrity",
        "magic_matches": matches,
        "entropy_bits_per_byte": _entropy(path),
        "timestamps": {
            "mtime": st.st_mtime, "atime": st.st_atime, "ctime": st.st_ctime,
        },
        "static_analysis_only": True,
    }
    if any("ZIP" in m for m in matches):
        normalized["archive"] = _zip_info(path)
    normalized["indicators"] = _iocs(path)

    raw = json.dumps({"file": path, "hashes": digests, "size": size,
                      "magic": matches}, indent=2).encode()
    return result("file", path, OK, raw=raw, normalized=normalized,
                  collector=COLLECTOR)
