"""Connector framework: standardized, provenance-carrying results.

Every connector returns the same shape so the evidence pipeline can
treat all sources uniformly. Connectors NEVER fabricate data: when a
source cannot be reached or credentials are missing, they return an
explicit failure status instead of invented content.
"""

import datetime
import hashlib
import json
import urllib.error
import urllib.parse
import urllib.request

from ..settings import COLLECTOR_VERSION, HTTP_TIMEOUT

# Collection statuses - the ONLY allowed outcomes.
OK = "OK"
NOT_FOUND = "NOT_FOUND"
SOURCE_UNAVAILABLE = "SOURCE_UNAVAILABLE"
ACCESS_RESTRICTED = "ACCESS_RESTRICTED"
AUTHENTICATION_REQUIRED = "AUTHENTICATION_REQUIRED"
COLLECTION_FAILED = "COLLECTION_FAILED"

USER_AGENT = f"WFIP/{COLLECTOR_VERSION} (authorized investigative collection)"

__all__ = [
    "OK", "NOT_FOUND", "SOURCE_UNAVAILABLE", "ACCESS_RESTRICTED",
    "AUTHENTICATION_REQUIRED", "COLLECTION_FAILED",
    "utcnow_iso", "sha256_bytes", "result", "http_get",
    "http_get_with_curl_fallback",
    "classify_http_error", "USER_AGENT",
]


def utcnow_iso():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def result(source, target, status, raw=b"", normalized=None, errors=None,
           collector="wfip/unknown"):
    raw = raw or b""
    return {
        "source": source,
        "target": target,
        "collected_at": utcnow_iso(),
        "status": status,
        "raw_evidence": raw,
        "normalized": normalized or {},
        "hash": sha256_bytes(raw),
        "errors": errors or [],
        "collector": collector,
        "collector_version": COLLECTOR_VERSION,
    }


def http_get(url, params=None, headers=None, timeout=HTTP_TIMEOUT):
    """GET with honest error classification. Returns (status, headers, body)."""
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    req_headers = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, headers=req_headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read()
        except Exception:
            body = b""
        return exc.code, dict(exc.headers or {}), body
    except urllib.error.URLError as exc:
        raise ConnectionError(f"network error: {exc.reason}")
    except TimeoutError:
        raise ConnectionError("timed out")
    except Exception as exc:  # noqa: BLE001
        raise ConnectionError(str(exc))


def classify_http_error(status):
    if status == 404:
        return NOT_FOUND
    if status in (401, 403):
        return ACCESS_RESTRICTED
    if status == 429:
        return SOURCE_UNAVAILABLE
    return COLLECTION_FAILED


def http_get_with_curl_fallback(url, params=None, headers=None, timeout=HTTP_TIMEOUT):
    """http_get, falling back to the system curl binary on connection failure.

    Some endpoints reset Python's TLS fingerprint at the egress layer while
    accepting curl. The fallback still fetches live data - never mocked.
    Returns (status, headers_dict, body) or raises ConnectionError.
    """
    try:
        return http_get(url, params=params, headers=headers, timeout=timeout)
    except ConnectionError:
        pass
    import shutil
    import subprocess
    if not shutil.which("curl"):
        raise ConnectionError("connection failed and no curl fallback available")
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    cmd = ["curl", "-sS", "-D", "-", "-o", "/tmp/wfip_curl_body",
           "--max-time", str(timeout), "-A", USER_AGENT]
    for k, v in (headers or {}).items():
        cmd += ["-H", f"{k}: {v}"]
    cmd.append(url)
    try:
        proc = subprocess.run(cmd, capture_output=True, timeout=timeout + 5)
    except (subprocess.TimeoutExpired, OSError) as exc:
        raise ConnectionError(f"curl fallback failed: {exc}")
    if proc.returncode != 0:
        raise ConnectionError(f"curl fallback failed: "
                              f"{proc.stderr.decode()[:200]}")
    try:
        with open("/tmp/wfip_curl_body", "rb") as fh:
            body = fh.read()
    except OSError:
        body = b""
    head, _, _ = proc.stdout.partition(b"\r\n\r\n")
    status, resp_headers = 0, {}
    lines = head.decode("latin1").split("\r\n")
    if lines and lines[0].startswith("HTTP/"):
        try:
            status = int(lines[0].split()[1])
        except (IndexError, ValueError):
            pass
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            resp_headers[k.strip()] = v.strip()
    return status, resp_headers, body
