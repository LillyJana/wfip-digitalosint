"""Authentication, RBAC, and TOTP-based MFA (stdlib implementation)."""

import base64
import datetime
import hashlib
import hmac
import secrets
import struct
import time

import bcrypt
import jwt
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from . import models
from .db import get_db
from .settings import JWT_ALGORITHM, JWT_EXPIRY_SECONDS, JWT_SECRET

bearer = HTTPBearer(auto_error=False)

ROLE_RANK = {"viewer": 1, "investigator": 2, "admin": 3}


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except Exception:
        return False


def create_token(user: models.User) -> str:
    now = datetime.datetime.now(datetime.timezone.utc)
    payload = {
        "sub": user.id,
        "username": user.username,
        "role": user.role,
        "iat": int(now.timestamp()),
        "exp": int((now + datetime.timedelta(seconds=JWT_EXPIRY_SECONDS)).timestamp()),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


def get_current_user(request: Request, credentials: HTTPAuthorizationCredentials = Depends(bearer),
                     db: Session = Depends(get_db)) -> models.User:
    if not credentials:
        raise HTTPException(status_code=401, detail="Authentication required")
    claims = decode_token(credentials.credentials)
    user = db.get(models.User, claims["sub"])
    if not user or not user.active:
        raise HTTPException(status_code=401, detail="Account disabled")
    request.state.user = user
    request.state.username = user.username
    return user


def require_role(*roles):
    def checker(user: models.User = Depends(get_current_user)):
        if user.role not in roles:
            raise HTTPException(status_code=403, detail="Insufficient role")
        return user
    return checker


def require_min_role(role: str):
    def checker(user: models.User = Depends(get_current_user)):
        if ROLE_RANK.get(user.role, 0) < ROLE_RANK.get(role, 99):
            raise HTTPException(status_code=403, detail="Insufficient role")
        return user
    return checker


def can_access_case(db: Session, user: models.User, case: models.Case) -> bool:
    if user.role == "admin":
        return True
    if case.created_by == user.id:
        return True
    return db.query(models.CaseMember).filter_by(case_id=case.id, user_id=user.id).first() is not None


def require_case_access(db: Session, user: models.User, case: models.Case):
    if not can_access_case(db, user, case):
        raise HTTPException(status_code=403, detail="No access to this case")


# ---- TOTP (RFC 6238), stdlib-only ----

def new_totp_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def totp_code(secret: str, for_time: float = None) -> str:
    for_time = for_time or time.time()
    key = base64.b32decode(secret + "=" * (-len(secret) % 8))
    counter = struct.pack(">Q", int(for_time // 30))
    digest = hmac.new(key, counter, hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF
    return str(code % 10**6).zfill(6)


def verify_totp(secret: str, code: str, window: int = 1) -> bool:
    now = time.time()
    for skew in range(-window, window + 1):
        if hmac.compare_digest(totp_code(secret, now + skew * 30), code):
            return True
    return False
