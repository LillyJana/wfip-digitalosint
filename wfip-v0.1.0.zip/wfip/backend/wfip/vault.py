"""Append-only evidence vault with hashing and chain-of-custody."""

import datetime
import hashlib
import json
import os

from sqlalchemy.orm import Session

from . import models
from .settings import COLLECTOR_VERSION, VAULT_DIR


def _utcnow():
    return datetime.datetime.now(datetime.timezone.utc)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _claim_evidence_dir(db: Session) -> tuple[str, str]:
    """Allocate a unique evidence ID AND its vault directory atomically.

    Retries past IDs whose directories exist from previously rolled-back
    transactions (the DB row was rolled back but the directory remained).
    """
    day = _utcnow().strftime("%Y%m%d")
    prefix = f"EV-{day}-"
    base = db.query(models.Evidence).filter(
        models.Evidence.evidence_id.like(prefix + "%")).count()
    for attempt in range(base + 1, base + 1000):
        evidence_id = f"{prefix}{attempt:04d}"
        edir = os.path.join(VAULT_DIR, "data", evidence_id)
        try:
            os.makedirs(edir, exist_ok=False)
            return evidence_id, edir
        except FileExistsError:
            continue  # orphaned by a rolled-back transaction; try next
    raise RuntimeError("could not allocate an evidence directory")


def store_evidence(db: Session, *, case: models.Case, collector: str, target: str,
                   source: str, evidence_type: str, raw: bytes,
                   normalized: dict, collection_status: str = "OK",
                   errors: list = None, created_by: models.User = None,
                   dev_fixture: bool = False) -> models.Evidence:
    """Write raw + normalized artifacts immutably; never overwrite."""
    evidence_id, edir = _claim_evidence_dir(db)
    digest = sha256_bytes(raw)
    raw_path = os.path.join(edir, "raw.bin")
    with open(raw_path, "wb") as fh:
        fh.write(raw)
    with open(os.path.join(edir, "normalized.json"), "w", encoding="utf-8") as fh:
        json.dump(normalized, fh, indent=2, default=str)
    meta = {
        "evidence_id": evidence_id,
        "collector": collector,
        "collector_version": COLLECTOR_VERSION,
        "target": target,
        "source": source,
        "evidence_type": evidence_type,
        "collected_at": _utcnow().isoformat(),
        "sha256": digest,
        "collection_status": collection_status,
        "dev_fixture": dev_fixture,
    }
    with open(os.path.join(edir, "meta.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2)

    ev = models.Evidence(
        evidence_id=evidence_id,
        case_id=case.id,
        collector=collector,
        collector_version=COLLECTOR_VERSION,
        target=target,
        source=source,
        evidence_type=evidence_type,
        status="DEV_FIXTURE" if dev_fixture else ("COLLECTED" if collection_status == "OK" else "COLLECTION_FAILED"),
        sha256=digest,
        raw_path=raw_path,
        normalized=normalized,
        collection_status=collection_status,
        errors=errors or [],
        created_by=created_by.id if created_by else None,
    )
    db.add(ev)
    db.flush()
    add_custody_event(db, ev, actor=created_by, action="COLLECTED",
                     reason=f"Collected by {collector} from {source}",
                     hash_at_time=digest)
    return ev


def verify_evidence(ev: models.Evidence) -> tuple[bool, str]:
    """Re-hash the stored raw artifact and compare with the recorded hash."""
    try:
        with open(ev.raw_path, "rb") as fh:
            digest = sha256_bytes(fh.read())
    except OSError as exc:
        return False, f"raw artifact unreadable: {exc}"
    if digest != ev.sha256:
        return False, "HASH MISMATCH - evidence may have been altered"
    return True, "hash verified"


def add_custody_event(db: Session, ev: models.Evidence, *, actor: models.User,
                      action: str, reason: str = "", hash_at_time: str = None):
    db.add(models.CustodyEvent(
        evidence_id=ev.id,
        actor_id=actor.id if actor else None,
        actor_name=actor.username if actor else "system",
        action=action,
        reason=reason,
        hash_at_time=hash_at_time or ev.sha256,
    ))


def audit(db: Session, *, actor: models.User | None, action: str,
          target_type: str = "", target_id: str = "", detail: str = "", ip: str = ""):
    db.add(models.AuditLog(
        actor_id=actor.id if actor else None,
        actor_name=actor.username if actor else "system",
        action=action, target_type=target_type, target_id=target_id,
        detail=detail, ip=ip,
    ))
