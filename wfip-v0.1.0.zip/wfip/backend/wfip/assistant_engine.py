"""Grounded investigation assistant.

The assistant reasons ONLY over evidence, entities, relationships and
timeline rows stored for the case. Every factual statement cites an
Evidence ID. When evidence is insufficient, it says so explicitly.
Findings are classified OBSERVED / CORROBORATED / HISTORICAL /
CORRELATED / INFERRED / UNVERIFIED.
"""

import re

from sqlalchemy.orm import Session

from . import models

INSUFFICIENT = "Insufficient evidence to establish this finding."


def _evid(db, case_id):
    return db.query(models.Evidence).filter_by(case_id=case_id).order_by(
        models.Evidence.collected_at).all()


def summarize_case(db: Session, case: models.Case) -> dict:
    evidence = _evid(db, case.id)
    ok_ev = [e for e in evidence if e.status == "COLLECTED"]
    failed = [e for e in evidence if e.status != "COLLECTED"]
    entities = db.query(models.Entity).filter_by(case_id=case.id).all()
    rels = db.query(models.Relationship).filter_by(case_id=case.id).all()
    by_type = {}
    for e in entities:
        by_type.setdefault(e.type, []).append(e.value)

    lines = [
        f"Case {case.case_id} contains {len(ok_ev)} collected evidence items "
        f"({len(failed)} failed/unavailable), {len(entities)} entities and "
        f"{len(rels)} relationships."
    ]
    findings = []
    for ev in ok_ev:
        findings.append({
            "evidence_id": ev.evidence_id,
            "classification": "OBSERVED",
            "statement": f"{ev.evidence_type} collected for target "
                         f"'{ev.target}' from {ev.source} "
                         f"(status {ev.collection_status}).",
        })
    for e in failed:
        findings.append({
            "evidence_id": e.evidence_id,
            "classification": "UNVERIFIED",
            "statement": f"Collection for '{e.target}' via {e.collector} did not "
                         f"succeed (status {e.collection_status}). "
                         f"No finding can be drawn from it.",
        })
    return {"summary": " ".join(lines), "findings": findings,
            "entity_types": {k: len(v) for k, v in by_type.items()}}


def extract_entities_text(db: Session, case: models.Case) -> dict:
    entities = db.query(models.Entity).filter_by(case_id=case.id).all()
    out = {}
    for e in entities:
        out.setdefault(e.type, []).append({"value": e.value,
                                           "entity_id": e.entity_id})
    return {"entities": out,
            "note": "Entities were extracted from collected evidence; "
                    "each entity links to its supporting evidence."}


def explain_evidence(db: Session, ev: models.Evidence) -> dict:
    norm = ev.normalized or {}
    expl = {
        "evidence_id": ev.evidence_id,
        "what": f"{ev.evidence_type} for '{ev.target}' collected from "
                f"{ev.source} at {ev.collected_at.isoformat()}.",
        "how": f"Collector {ev.collector} version {ev.collector_version}. "
               f"Raw bytes preserved (SHA-256 {ev.sha256}).",
        "status": ev.collection_status,
        "caveats": [],
    }
    if ev.collector == "wfip/ip" and (norm.get("geolocation") or {}).get("provenance"):
        expl["caveats"].append("Geolocation is approximate third-party data, "
                               "not authoritative.")
    if ev.collector in ("wfip/dns", "wfip/rdap"):
        expl["caveats"].append("Registration/infrastructure data describes "
                               "technical delegation, not verified ownership.")
    if ev.collector == "wfip/email":
        expl["caveats"].append("Headers are header-declared; they do not prove authorship.")
    if ev.collector == "wfip/threatintel":
        expl["caveats"].append("Threat-intel verdicts are third-party opinions, "
                               "not ground truth.")
    if ev.errors:
        expl["caveats"].append("Collection notes: " + "; ".join(ev.errors))
    return expl


def find_relationships(db: Session, case: models.Case, entity_value: str) -> dict:
    ents = db.query(models.Entity).filter_by(case_id=case.id).filter(
        models.Entity.value.like(f"%{entity_value}%")).limit(10).all()
    if not ents:
        return {"answer": INSUFFICIENT, "matches": []}
    matches = []
    for ent in ents:
        rels = db.query(models.Relationship).filter(
            (models.Relationship.from_entity_id == ent.id) |
            (models.Relationship.to_entity_id == ent.id)).all()
        for r in rels:
            other = db.get(models.Entity, r.to_entity_id
                           if r.from_entity_id == ent.id else r.from_entity_id)
            ev = db.get(models.Evidence, r.evidence_id) if r.evidence_id else None
            matches.append({
                "entity": f"{ent.type}:{ent.value}",
                "relationship": r.rel_type,
                "other": f"{other.type}:{other.value}" if other else "?",
                "provenance": r.provenance,
                "evidence_id": ev.evidence_id if ev else None,
                "detail": r.detail,
            })
    if not matches:
        return {"answer": INSUFFICIENT, "matches": []}
    return {"answer": f"{len(matches)} relationship(s) observed for entities "
                     f"matching '{entity_value}'.", "matches": matches}


def detect_inconsistencies(db: Session, case: models.Case) -> dict:
    """Cross-check evidence for contradictions - reported as UNVERIFIED leads."""
    issues = []
    evidence = _evid(db, case.id)
    # Example: RDAP creation date vs certificate not-before predating domain.
    rdap_dates, cert_dates = {}, []
    for ev in evidence:
        norm = ev.normalized or {}
        if ev.collector == "wfip/rdap":
            for action, date in (norm.get("events") or {}).items():
                if "creat" in action.lower():
                    rdap_dates[ev.target] = date
        if ev.collector == "wfip/tls" and norm.get("not_before"):
            cert_dates.append((ev.target, norm["not_before"], ev.evidence_id))
    for target, nb, eid in cert_dates:
        issues.append({
            "classification": "UNVERIFIED",
            "evidence_id": eid,
            "statement": f"Certificate for '{target}' reports not-before "
                         f"{nb}. Compare with RDAP creation events before "
                         f"drawing conclusions about issuance order.",
        })
    # Failed collections worth re-trying
    for ev in evidence:
        if ev.collection_status in ("SOURCE_UNAVAILABLE", "COLLECTION_FAILED",
                                    "AUTHENTICATION_REQUIRED"):
            issues.append({
                "classification": "UNVERIFIED",
                "evidence_id": ev.evidence_id,
                "statement": f"Collection '{ev.collector}' for '{ev.target}' "
                             f"returned {ev.collection_status}; the question it "
                             f"was meant to answer remains open.",
            })
    return {"issues": issues}


def answer(db: Session, case: models.Case, question: str) -> dict:
    q = question.lower()
    if any(w in q for w in ("summar", "overview", "what do we know", "status")):
        s = summarize_case(db, case)
        return {"answer": s["summary"], "findings": s["findings"],
                "citations": [f["evidence_id"] for f in s["findings"]]}
    if "entit" in q:
        e = extract_entities_text(db, case)
        return {"answer": "Entities extracted from collected evidence: " +
                ", ".join(f"{k} ({len(v)})" for k, v in e["entities"].items()),
                "entities": e["entities"], "citations": []}
    if "inconsist" in q or "contradict" in q or "gap" in q:
        d = detect_inconsistencies(db, case)
        return {"answer": f"{len(d['issues'])} potential issue(s) found. "
                          "Each is UNVERIFIED until corroborated.",
                "issues": d["issues"],
                "citations": [i["evidence_id"] for i in d["issues"] if i.get("evidence_id")]}
    # relationship query: "relationships of X" / "connected to X"
    m = re.search(r"(?:of|for|to)\s+([a-z0-9.\-_:]+)", q)
    if "relation" in q or "connect" in q or "link" in q:
        if m:
            r = find_relationships(db, case, m.group(1))
            return {"answer": r["answer"], "matches": r["matches"],
                    "citations": [x["evidence_id"] for x in r["matches"] if x.get("evidence_id")]}
        return {"answer": INSUFFICIENT, "matches": []}
    # timeline
    if "timeline" in q or "when" in q or "chronolog" in q:
        events = db.query(models.TimelineEvent).filter_by(case_id=case.id).order_by(
            models.TimelineEvent.timestamp).limit(50).all()
        if not events:
            return {"answer": INSUFFICIENT, "events": []}
        evs = [{"timestamp": t.timestamp.isoformat(), "event": t.event_type,
                "target": t.target, "classification": t.classification,
                "evidence_id": (db.get(models.Evidence, t.evidence_id).evidence_id
                                if t.evidence_id else None)} for t in events]
        return {"answer": f"{len(evs)} timeline event(s) in case evidence.",
                "events": evs,
                "citations": [e["evidence_id"] for e in evs if e["evidence_id"]]}
    return {"answer": "I can summarize the case, list entities, show "
                     "relationships for a named entity, build the timeline, or "
                     "check for inconsistencies - all grounded in collected "
                     "evidence. Please rephrase.",
            "citations": []}
