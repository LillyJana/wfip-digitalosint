"""SQLAlchemy models: users, cases, evidence, entities, audit."""

import datetime
import uuid

from sqlalchemy import (Boolean, Column, DateTime, ForeignKey, Integer, String,
                        Text, UniqueConstraint)
from sqlalchemy.types import JSON

from .db import Base


def utcnow():
    return datetime.datetime.now(datetime.timezone.utc)


class User(Base):
    __tablename__ = "users"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String(64), unique=True, nullable=False, index=True)
    password_hash = Column(String(128), nullable=False)
    role = Column(String(16), nullable=False, default="investigator")  # admin/investigator/viewer
    totp_secret = Column(String(64), nullable=True)
    totp_enabled = Column(Boolean, default=False)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=utcnow)


class Case(Base):
    __tablename__ = "cases"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id = Column(String(32), unique=True, nullable=False, index=True)  # CASE-0001
    title = Column(String(256), nullable=False)
    description = Column(Text, default="")
    classification = Column(String(32), default="UNCLASSIFIED")
    status = Column(String(32), default="OPEN")  # OPEN/IN_PROGRESS/CLOSED/ARCHIVED
    created_by = Column(String(36), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), default=utcnow)
    updated_at = Column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class CaseMember(Base):
    __tablename__ = "case_members"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id = Column(String(36), ForeignKey("cases.id"), index=True)
    user_id = Column(String(36), ForeignKey("users.id"))
    role = Column(String(16), default="investigator")  # lead/investigator/viewer
    __table_args__ = (UniqueConstraint("case_id", "user_id"),)


class CaseNote(Base):
    __tablename__ = "case_notes"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id = Column(String(36), ForeignKey("cases.id"), index=True)
    author_id = Column(String(36), ForeignKey("users.id"))
    body = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), default=utcnow)


class Evidence(Base):
    __tablename__ = "evidence"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    evidence_id = Column(String(40), unique=True, nullable=False, index=True)  # EV-20261003-0001
    case_id = Column(String(36), ForeignKey("cases.id"), index=True)
    collector = Column(String(64), nullable=False)
    collector_version = Column(String(32), nullable=False)
    target = Column(String(512), nullable=False)
    source = Column(String(128), nullable=False)
    evidence_type = Column(String(64), nullable=False)
    # COLLECTED | DEV_FIXTURE | COLLECTION_FAILED
    status = Column(String(32), default="COLLECTED")
    collected_at = Column(DateTime(timezone=True), default=utcnow, index=True)
    sha256 = Column(String(64), nullable=False)
    raw_path = Column(String(512), nullable=False)
    normalized = Column(JSON, default=dict)
    collection_status = Column(String(32), default="OK")  # OK/NOT_FOUND/SOURCE_UNAVAILABLE/...
    errors = Column(JSON, default=list)
    created_by = Column(String(36), ForeignKey("users.id"))


class CustodyEvent(Base):
    __tablename__ = "custody"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    evidence_id = Column(String(36), ForeignKey("evidence.id"), index=True)
    actor_id = Column(String(36), ForeignKey("users.id"))
    actor_name = Column(String(64))
    action = Column(String(64), nullable=False)  # COLLECTED/ACCESSED/EXPORTED/VERIFIED
    reason = Column(String(256), default="")
    hash_at_time = Column(String(64))
    timestamp = Column(DateTime(timezone=True), default=utcnow)


class Entity(Base):
    __tablename__ = "entities"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    entity_id = Column(String(40), unique=True, nullable=False, index=True)  # ENT-...
    case_id = Column(String(36), ForeignKey("cases.id"), index=True)
    type = Column(String(32), nullable=False, index=True)  # domain/ip/asn/url/...
    value = Column(String(1024), nullable=False, index=True)
    attributes = Column(JSON, default=dict)
    first_seen = Column(DateTime(timezone=True), default=utcnow)
    last_seen = Column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (UniqueConstraint("case_id", "type", "value"),)


class Relationship(Base):
    __tablename__ = "relationships"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id = Column(String(36), ForeignKey("cases.id"), index=True)
    from_entity_id = Column(String(36), ForeignKey("entities.id"), index=True)
    to_entity_id = Column(String(36), ForeignKey("entities.id"), index=True)
    rel_type = Column(String(32), nullable=False)  # RESOLVES_TO/HOSTED_ON/...
    evidence_id = Column(String(36), ForeignKey("evidence.id"))
    # OBSERVED | CORROBORATED | HISTORICAL | CORRELATED | INFERRED | UNVERIFIED
    provenance = Column(String(16), default="OBSERVED")
    detail = Column(String(512), default="")


class TimelineEvent(Base):
    __tablename__ = "timeline"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id = Column(String(36), ForeignKey("cases.id"), index=True)
    timestamp = Column(DateTime(timezone=True), nullable=False, index=True)
    event_type = Column(String(64), nullable=False)
    target = Column(String(512))
    source = Column(String(128))
    evidence_id = Column(String(36), ForeignKey("evidence.id"), nullable=True)
    # CURRENT | HISTORICAL | CORRELATION | INFERENCE
    classification = Column(String(16), default="CURRENT")
    detail = Column(Text, default="")


class AuditLog(Base):
    __tablename__ = "audit"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    timestamp = Column(DateTime(timezone=True), default=utcnow, index=True)
    actor_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    actor_name = Column(String(64), default="system")
    action = Column(String(64), nullable=False, index=True)
    target_type = Column(String(32), default="")
    target_id = Column(String(64), default="")
    detail = Column(Text, default="")
    ip = Column(String(64), default="")


class CollectionJob(Base):
    __tablename__ = "jobs"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id = Column(String(36), ForeignKey("cases.id"), index=True)
    kind = Column(String(32), nullable=False)  # domain/ip/url/email/file
    target = Column(String(512), nullable=False)
    status = Column(String(32), default="RUNNING")  # RUNNING/DONE/FAILED
    evidence_ids = Column(JSON, default=list)
    error = Column(Text, default="")
    created_by = Column(String(36), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), default=utcnow)


class Report(Base):
    __tablename__ = "reports"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    report_id = Column(String(40), unique=True, nullable=False, index=True)  # RPT-...
    case_id = Column(String(36), ForeignKey("cases.id"), index=True)
    title = Column(String(256), default="")
    path = Column(String(512), nullable=False)
    sha256 = Column(String(64), nullable=False)
    evidence_count = Column(Integer, default=0)
    created_by = Column(String(36), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), default=utcnow)
