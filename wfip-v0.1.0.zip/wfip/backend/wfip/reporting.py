"""Professional HTML investigation reports.

Every finding references its supporting Evidence ID. The report states
its limitations explicitly and never upgrades correlation to proof.
"""

import datetime
import html
import os

from sqlalchemy.orm import Session

from . import models
from .settings import APP_VERSION
from .vault import sha256_bytes

REPORT_DIR = os.path.join(os.environ.get("WFIP_VAULT_DIR", "./vault"), "reports")


def _esc(value):
    return html.escape(str(value) if value is not None else "-")


def _section(title, body):
    return f"<section><h2>{_esc(title)}</h2>{body}</section>"


def _table(headers, rows):
    th = "".join(f"<th>{_esc(h)}</th>" for h in headers)
    tr = "".join("<tr>" + "".join(f"<td>{_esc(c)}</td>" for c in r) + "</tr>"
                 for r in rows)
    return f"<table><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>"


def generate(db: Session, case: models.Case, investigator: models.User) -> dict:
    evidence = db.query(models.Evidence).filter_by(case_id=case.id).order_by(
        models.Evidence.collected_at).all()
    entities = db.query(models.Entity).filter_by(case_id=case.id).all()
    rels = db.query(models.Relationship).filter_by(case_id=case.id).all()
    timeline = db.query(models.TimelineEvent).filter_by(case_id=case.id).order_by(
        models.TimelineEvent.timestamp).all()
    notes = db.query(models.CaseNote).filter_by(case_id=case.id).order_by(
        models.CaseNote.created_at).all()
    ent_by_id = {e.id: e for e in entities}
    ev_by_id = {e.id: e for e in evidence}

    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    parts = []

    # Header
    parts.append(f"""<header>
<h1>Investigation Report</h1>
<p class="case-id">{_esc(case.case_id)} &mdash; {_esc(case.title)}</p>
<p>Classification: <strong>{_esc(case.classification)}</strong> |
Status: {_esc(case.status)} |
Generated: {_esc(now)} by {_esc(investigator.username)} |
WFIP {APP_VERSION}</p>
</header>""")

    # Executive summary (grounded counts only)
    ok_ev = [e for e in evidence if e.status == "COLLECTED"]
    parts.append(_section("Executive summary", f"""
<p>This report summarizes evidence collected for case <strong>{_esc(case.case_id)}</strong>.
It contains <strong>{len(ok_ev)}</strong> collected evidence items,
<strong>{len(entities)}</strong> entities, <strong>{len(rels)}</strong>
relationships and <strong>{len(timeline)}</strong> timeline events.
Every factual finding below references its supporting evidence ID.
Correlations are labeled as correlations; they are not proof of common
ownership or control.</p>
<p><em>Case description:</em> {_esc(case.description)}</p>"""))

    # Findings by evidence
    findings = []
    for ev in evidence:
        norm = ev.normalized or {}
        summary = _summarize_evidence(ev, norm)
        findings.append(f"""<div class="finding">
<h3>{_esc(ev.evidence_type)} &mdash; {_esc(ev.target)}</h3>
<p>Evidence ID: <code>{_esc(ev.evidence_id)}</code> |
Source: {_esc(ev.source)} | Collector: {_esc(ev.collector)}
{_esc(ev.collector_version)} |
Collected: {_esc(ev.collected_at.isoformat())} |
SHA-256: <code>{_esc(ev.sha256)}</code> |
Status: {_esc(ev.collection_status)}</p>
{summary}
{"<p class='errors'>Collection notes: " + _esc("; ".join(ev.errors)) + "</p>" if ev.errors else ""}
</div>""")
    parts.append(_section("Observed findings", "\n".join(findings) if findings else "<p>No evidence collected.</p>"))

    # Entity graph summary
    by_type = {}
    for e in entities:
        by_type.setdefault(e.type, []).append(e)
    rows = [[t, len(v), ", ".join(x.value[:60] for x in v[:8])] for t, v in sorted(by_type.items())]
    parts.append(_section("Entities", _table(["Type", "Count", "Examples"], rows) if rows else "<p>None.</p>"))

    # Relationships with provenance
    rel_rows = []
    for r in rels:
        f, t = ent_by_id.get(r.from_entity_id), ent_by_id.get(r.to_entity_id)
        ev = ev_by_id.get(r.evidence_id)
        rel_rows.append([
            f"{f.type}:{f.value[:50]}" if f else "?",
            r.rel_type,
            f"{t.type}:{t.value[:50]}" if t else "?",
            r.provenance,
            ev.evidence_id if ev else "-",
        ])
    parts.append(_section("Relationships (with provenance)",
                          _table(["From", "Relationship", "To", "Provenance", "Evidence"], rel_rows) if rel_rows else "<p>None.</p>"))

    # Timeline
    tl_rows = [[t.timestamp.isoformat(), t.event_type, t.target or "-",
                t.classification,
                (db.get(models.Evidence, t.evidence_id).evidence_id if t.evidence_id else "-"),
                (t.detail or "")[:200]] for t in timeline]
    parts.append(_section("Timeline", _table(
        ["Timestamp", "Event", "Target", "Classification", "Evidence", "Detail"], tl_rows) if tl_rows else "<p>None.</p>"))

    # Evidence table + chain of custody
    ev_rows = [[e.evidence_id, e.evidence_type, e.target[:60], e.source,
                e.collected_at.isoformat(), e.sha256[:16] + "...",
                e.collection_status] for e in evidence]
    parts.append(_section("Evidence table", _table(
        ["Evidence ID", "Type", "Target", "Source", "Collected", "SHA-256", "Status"], ev_rows)))

    custody_rows = []
    for ev in evidence:
        for c in db.query(models.CustodyEvent).filter_by(
                evidence_id=ev.id).order_by(models.CustodyEvent.timestamp):
            custody_rows.append([ev.evidence_id, c.timestamp.isoformat(),
                                 c.actor_name, c.action, c.reason[:120],
                                 (c.hash_at_time or "")[:16] + "..."])
    parts.append(_section("Chain of custody", _table(
        ["Evidence", "Timestamp", "Actor", "Action", "Reason", "Hash"], custody_rows)))

    # Notes
    if notes:
        parts.append(_section("Investigator notes",
                              "".join(f"<p><strong>{_esc(db.get(models.User, n.author_id).username)}</strong> "
                                      f"({_esc(n.created_at.isoformat())}): {_esc(n.body)}</p>" for n in notes)))

    # Limitations - always present
    parts.append(_section("Limitations", """<ul>
<li>Shared infrastructure (IP, certificate, nameserver) is a correlation, not proof of common ownership or control.</li>
<li>Third-party database content (geolocation, reputation) is approximate and not authoritative.</li>
<li>Email headers are header-declared values; they do not by themselves prove authorship.</li>
<li>RDAP/WHOIS data reflects registry claims, not verified identity.</li>
<li>Absence of evidence is not evidence of absence; NOT_FOUND means "not observed", not "does not exist".</li>
<li>Username/platform presence checks elsewhere in the toolkit are heuristics and require manual verification.</li>
</ul>"""))

    doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>Investigation Report {_esc(case.case_id)}</title>
<style>
body{{font-family:Georgia,serif;max-width:1000px;margin:2rem auto;padding:0 1.5rem;color:#1a1a1a;line-height:1.6}}
header{{border-bottom:3px solid #1a1a1a;padding-bottom:1rem;margin-bottom:2rem}}
.case-id{{font-size:1.4rem;font-weight:bold}}
h2{{border-bottom:1px solid #ccc;padding-bottom:.3rem;margin-top:2.5rem}}
table{{border-collapse:collapse;width:100%;font-size:.85rem;margin:1rem 0}}
th,td{{border:1px solid #ccc;padding:.4rem .6rem;text-align:left;vertical-align:top}}
th{{background:#f0f0f0}}
code{{background:#f4f4f4;padding:.1rem .3rem;font-size:.85em;word-break:break-all}}
.finding{{border:1px solid #ddd;padding:1rem;margin:1rem 0;border-radius:4px}}
.errors{{color:#8a5a00}}
footer{{margin-top:3rem;border-top:1px solid #ccc;padding-top:1rem;font-size:.8rem;color:#666}}
@media print{{body{{max-width:100%}}}}
</style></head><body>
{''.join(parts)}
<footer>Generated by {_esc("World Forensic Intelligence Platform")} {APP_VERSION}.
Print to PDF from the browser for a PDF copy. Report integrity is bound to the
evidence SHA-256 hashes listed above.</footer>
</body></html>"""

    os.makedirs(REPORT_DIR, exist_ok=True)
    count = db.query(models.Report).filter_by(case_id=case.id).count()
    report_id = f"RPT-{case.case_id}-{count + 1:03d}"
    path = os.path.join(REPORT_DIR, f"{report_id}.html")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(doc)
    digest = sha256_bytes(doc.encode())
    rep = models.Report(report_id=report_id, case_id=case.id,
                        title=f"Investigation Report {case.case_id}",
                        path=path, sha256=digest,
                        evidence_count=len(evidence),
                        created_by=investigator.id)
    db.add(rep)
    db.commit()
    return {"report_id": report_id, "path": path, "sha256": digest,
            "evidence_count": len(evidence)}


def _summarize_evidence(ev: models.Evidence, norm: dict) -> str:
    """Short grounded summary per evidence type (facts only, from normalized)."""
    items = []
    def add(label, value):
        if value:
            items.append(f"<li><strong>{_esc(label)}:</strong> {_esc(str(value)[:500])}</li>")
    c = ev.collector
    if c == "wfip/dns":
        for qt in ("A", "AAAA", "MX", "NS", "TXT", "SOA", "CAA"):
            vals = norm.get(qt)
            if vals:
                add(f"DNS {qt}", "; ".join(str(v)[:120] for v in vals[:10]))
        ea = norm.get("email_auth", {})
        if ea.get("spf"): add("SPF", "; ".join(ea["spf"]))
        if ea.get("dmarc"): add("DMARC", "; ".join(ea["dmarc"]))
    elif c == "wfip/rdap":
        add("Handle", norm.get("handle")); add("Status", norm.get("status"))
        reg = norm.get("registrar") or {}
        if reg: add("Registrar", reg.get("handle"))
        evts = norm.get("events") or {}
        if evts: add("Registry events", "; ".join(f"{k}={v}" for k, v in evts.items()))
    elif c == "wfip/ip":
        add("Reverse DNS", norm.get("reverse_dns"))
        geo = norm.get("geolocation") or {}
        if geo: add("Geolocation", f"{geo.get('city')}, {geo.get('country')} (AS {geo.get('as')}, {geo.get('org')})")
    elif c == "wfip/http":
        add("Final URL", norm.get("final_url"))
        add("Status", norm.get("http_status"))
        chain = norm.get("redirect_chain", [])
        if len(chain) > 1: add("Redirects", " -> ".join(h["url"][:60] for h in chain))
        page = norm.get("page") or {}
        if page.get("title"): add("Title", page["title"])
        if page.get("linked_domains"): add("Linked domains", ", ".join(page["linked_domains"][:15]))
        add("Body SHA-256", norm.get("body_sha256"))
    elif c == "wfip/tls":
        add("Subject", norm.get("subject")); add("Issuer", norm.get("issuer"))
        add("Validity", f"{norm.get('not_before')} to {norm.get('not_after')}")
        add("Fingerprint", norm.get("sha256_fingerprint"))
        if norm.get("san"): add("SANs", ", ".join(norm["san"][:10]))
    elif c == "wfip/certificates":
        add("Certificates observed", norm.get("certificate_count"))
    elif c == "wfip/email":
        hdrs = norm.get("headers", {})
        for k in ("From", "To", "Date", "Subject"):
            if hdrs.get(k): add(k, "; ".join(hdrs[k][:3]))
        chain = norm.get("received_chain", [])
        if chain: add("Received hops", f"{len(chain)} hops, earliest {chain[0].get('date')}")
        if norm.get("attachments"): add("Attachments", f"{len(norm['attachments'])}")
    elif c == "wfip/file":
        add("SHA-256", norm.get("sha256")); add("Size", norm.get("size"))
        if norm.get("magic_matches"): add("Type", "; ".join(norm["magic_matches"]))
    elif c == "wfip/threatintel":
        for k, v in norm.items():
            if k != "provenance" and v is not None: add(k, v)
    if not items:
        return "<p><em>Raw evidence preserved; see normalized JSON in evidence detail.</em></p>"
    return "<ul>" + "".join(items) + "</ul>"
