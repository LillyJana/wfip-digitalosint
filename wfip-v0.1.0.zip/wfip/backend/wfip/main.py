"""WFIP FastAPI application."""

import os
import time

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from . import models
from .auth import hash_password
from .db import SessionLocal, init_db
from .routers import auth_r, cases, collect, investigate, meta
from .settings import APP_NAME, APP_VERSION, EPHEMERAL_JWT, RATE_LIMIT_PER_MINUTE
from .vault import audit

app = FastAPI(title=APP_NAME, version=APP_VERSION,
              docs_url="/api/docs", redoc_url="/api/redoc")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)

# ---- simple in-memory rate limiter ----
_hits: dict[str, list[float]] = {}


@app.middleware("http")
async def rate_limit(request: Request, call_next):
    if request.url.path.startswith("/api/"):
        key = request.client.host if request.client else "unknown"
        now = time.time()
        window = [t for t in _hits.get(key, []) if now - t < 60]
        if len(window) >= RATE_LIMIT_PER_MINUTE:
            return JSONResponse({"detail": "Rate limit exceeded"}, status_code=429)
        window.append(now)
        _hits[key] = window
    return await call_next(request)


app.include_router(auth_r.router, prefix="/api")
app.include_router(cases.router, prefix="/api")
app.include_router(collect.router, prefix="/api")
app.include_router(investigate.router, prefix="/api")
app.include_router(meta.reports_router, prefix="/api")
app.include_router(meta.assistant_router, prefix="/api")
app.include_router(meta.system_router, prefix="/api")


@app.on_event("startup")
def startup():
    init_db()
    db = SessionLocal()
    try:
        if not db.query(models.User).filter_by(username="admin").first():
            db.add(models.User(username="admin",
                               password_hash=hash_password("ChangeMe123!"),
                               role="admin"))
            audit(db, actor=None, action="SEED_ADMIN",
                  detail="default admin created - password must be changed")
            db.commit()
            print("WFIP: default admin created (username=admin password=ChangeMe123!) - CHANGE IT")
        if EPHEMERAL_JWT:
            print("WFIP WARNING: WFIP_JWT_SECRET not set - using ephemeral secret. "
                  "Not production-safe.")
    finally:
        db.close()


@app.get("/api")
def api_root():
    return {"app": APP_NAME, "version": APP_VERSION}


# ---- frontend (investigator dashboard SPA) ----
_frontend = os.path.join(os.path.dirname(os.path.dirname(__file__)), "..",
                         "frontend")
_frontend = os.path.abspath(_frontend)
if os.path.isdir(_frontend):
    app.mount("/", StaticFiles(directory=_frontend, html=True), name="frontend")
